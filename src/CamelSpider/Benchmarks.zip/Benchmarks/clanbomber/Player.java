import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JLabel;

public class Player extends JLabel implements MyRunnable {
	private int keys[] = new int[5];
	private int key = 0;
	private int bomb = 0;
	private int dead = 0;

	public void setKick(int kick) {
		this.kick = kick;
	}

	public int getDead() {
		return dead;
	}

	private int index;
	private int character = 0;
	private int group = 0;

	public int getGroup() {
		return group;
	}

	public void setDead(int dead) {
		this.dead = dead;
	}

	public void setBomb(int bomb) {
		this.bomb = bomb;
	}

	private int speed = 1;// 1-15
	private int s = 1;
	private int gap = 1;// 1-5
	private int slip = 2;// gap+1-20
	private int sc = 0;
	private int power = 1;

	public int getBombs() {
		return bombs;
	}

	public void setBombs(int bombs) {
		this.bombs = bombs;
	}

	public int getCharacter() {
		return character;
	}

	public void setCharacter(int character) {
		this.character = character;
	}

	public int getGap() {
		return gap;
	}

	public void setGap(int gap) {
		this.gap = gap;
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	public int[] getKeys() {
		return keys;
	}

	public void setKeys(int[] keys) {
		this.keys = keys;
	}

	public int getPower() {
		return power;
	}

	public void setPower(int power) {
		this.power = power;
	}

	public int getS() {
		return s;
	}

	public void setS(int s) {
		this.s = s;
	}

	public int getSc() {
		return sc;
	}

	public void setSc(int sc) {
		this.sc = sc;
	}

	public int getSlip() {
		return slip;
	}

	public void setSlip(int slip) {
		this.slip = slip;
	}

	public int getSpeed() {
		return speed;
	}

	public void setSpeed(int speed) {
		this.speed = speed;
	}

	private int bombs = 1;
	private int kick = 0;

	public int getKick() {
		return kick;
	}

	public void addBomb() {
		bombs++;
	}

	public int getKeys(int index) {
		return keys[index];
	}

	public int getKey() {
		return key;
	}

	public void setKey(int k) {
		key = k;
	}

	public Player(int left, int right, int down, int up, int bom, int index,
			int chara, int group) {
		keys[0] = left;
		keys[1] = right;
		keys[2] = down;
		keys[3] = up;
		keys[4] = bom;
		this.setSize(40, 40);
		this.setLocation(0, 0);
		character = chara;
		this.setIcon(Main.images.player[character][0]);
		this.index = index;

		this.group = group;
	}

	public void run() {
		try {
			Thread.sleep(1);
		} catch (InterruptedException ex) {
			Logger.getLogger(Player.class.getName())
					.log(Level.SEVERE, null, ex);
		}
		int i, j;
		while (dead == 0) {

			i = this.getX();
			j = this.getY();

			if (Main.game.getFire(((i + 20) / 40), ((j - 20) / 40)).getOn() == 1)
				setDead(1);

			if (Main.game.getCell(((i + 20) / 40), ((j - 20) / 40)).isFood() == 1) {
				if (Main.game.getCell(((i + 20) / 40), ((j - 20) / 40))
						.getFood() == 0) {
					if (bombs < 15)
						bombs++;
				} else if (Main.game.getCell(((i + 20) / 40), ((j - 20) / 40))
						.getFood() == 1) {
					if (power < 15)
						power++;
				} else if (Main.game.getCell(((i + 20) / 40), ((j - 20) / 40))
						.getFood() == 2) {
					if (speed < 15)
						speed++;
				} else if (Main.game.getCell(((i + 20) / 40), ((j - 20) / 40))
						.getFood() == 3) {
					kick = 1;
				}
				Main.speaker.Play(Main.speaker.WOW);
				Main.game.getCell(((i + 20) / 40), ((j - 20) / 40)).eatFood();
			}

			if (bomb == 1) {
				if (bombs > 0) {
					bombs--;
					Bomb b = new Bomb(power, index, character);
					b.setLocation(((i + 20) / 40) * 40, ((j + 20) / 40) * 40);
					Main.game.placeBomb(b);
					bomb = 0;
					Main.speaker.Play(Main.speaker.PUTBOMB);
					Thread o = new MyThread(b);
					o.start();
				} else
					bomb = 0;
			}

			sc++;
			if (sc == (17 - speed))
				sc = 0;

			for (int o = 0; o < s; o++) {
				if (key == keys[0] && sc == 0) {
					this.setIcon(Main.images.player[character][0]);
					if (i > 0) {
						if (Main.game.getCell((i + gap - 1) / 40,
								(j + 40 - gap) / 40 - 1).isSolid(i + gap,
								j + gap) == false
								&& Main.game.getCell((i + gap - 1) / 40,
										(j + gap) / 40 - 1).isSolid(i + gap,
										j + gap) == false)
							i--;
						else if (Main.game.getCell((i + gap - 1) / 40,
								(j + 40 - gap) / 40 - 1).isSolid(i + gap,
								j + gap) == true
								&& Main.game.getCell((i + gap - 1) / 40,
										(j + slip) / 40 - 1).isSolid(i + gap,
										j + gap) == false)// &&
															// Main.game.getCell((i+gap)/40,
															// (j-gap)/40-1).isSolid(i+gap,
															// j+gap) == false)
						{
							j--;
							if (Main.game.getCell((i + gap - 1) / 40,
									(j + 40 - gap) / 40 - 1).isSolid(i + gap,
									j + gap) == false
									&& Main.game.getCell((i + gap - 1) / 40,
											(j + gap) / 40 - 1).isSolid(
											i + gap, j + gap) == false)
								i--;
						} else if (Main.game.getCell((i + gap - 1) / 40,
								(j + 40 - slip) / 40 - 1).isSolid(i + gap,
								j + gap) == false
								&& Main.game.getCell((i + gap - 1) / 40,
										(j + gap) / 40 - 1).isSolid(i + gap,
										j + gap) == true)
							j++;

					}

				}

				else if (key == keys[1] && sc == 0) {
					this.setIcon(Main.images.player[character][2]);
					if (i < 760) {
						if (Main.game.getCell((i + 40 - gap) / 40,
								(j + 40 - gap) / 40 - 1).isSolid(i + gap,
								j + gap) == false
								&& Main.game.getCell((i + 40 - gap) / 40,
										(j + gap) / 40 - 1).isSolid(i + gap,
										j + gap) == false)
							i++;
						else if (Main.game.getCell((i + 40 - gap) / 40,
								(j + 40 - gap) / 40 - 1).isSolid(i + gap,
								j + gap) == true
								&& Main.game.getCell((i + 40 - gap) / 40,
										(j + slip) / 40 - 1).isSolid(i + gap,
										j + gap) == false) {
							j--;
							if (Main.game.getCell((i + 40 - gap) / 40,
									(j + 40 - gap) / 40 - 1).isSolid(i + gap,
									j + gap) == false
									&& Main.game.getCell((i + 40 - gap) / 40,
											(j + gap) / 40 - 1).isSolid(
											i + gap, j + gap) == false)
								i++;
						}

						else if (Main.game.getCell((i + 40 - gap) / 40,
								(j + 40 - slip) / 40 - 1).isSolid(i + gap,
								j + gap) == false
								&& Main.game.getCell((i + 40 - gap) / 40,
										(j + gap) / 40 - 1).isSolid(i + gap,
										j + gap) == true)
							j++;

					}
				}

				else if (key == keys[2] && sc == 0) {
					this.setIcon(Main.images.player[character][3]);
					if (j > 40) {
						if (Main.game.getCell((i + 40 - gap) / 40,
								(j - gap) / 40 - 1).isSolid(i + gap, j + gap) == false
								&& Main.game.getCell((i + gap) / 40,
										(j - gap) / 40 - 1).isSolid(i + gap,
										j + gap) == false)
							j--;
						else if (Main.game.getCell((i + 40 - gap) / 40,
								(j - gap) / 40 - 1).isSolid(i + gap, j + gap) == true
								&& Main.game.getCell((i + slip) / 40,
										(j - gap) / 40 - 1).isSolid(i + gap,
										j + gap) == false)
							i--;
						else if (Main.game.getCell((i + 40 - slip) / 40,
								(j - gap) / 40 - 1).isSolid(i + gap, j + gap) == false
								&& Main.game.getCell((i + gap) / 40,
										(j - gap) / 40 - 1).isSolid(i + gap,
										j + gap) == true)
							i++;
					}
				} else if (key == keys[3] && sc == 0) {
					this.setIcon(Main.images.player[character][1]);
					if (j < 560) {
						if (Main.game.getCell((i + 40 - gap) / 40,
								(j + 40 - gap) / 40 - 1).isSolid(i + gap,
								j + gap) == false
								&& Main.game.getCell((i + gap) / 40,
										(j + 40 - gap) / 40 - 1).isSolid(
										i + gap, j + gap) == false)
							j++;
						else if (Main.game.getCell((i + 40 - gap) / 40,
								(j + 40 - gap) / 40 - 1).isSolid(i + gap,
								j + gap) == true
								&& Main.game.getCell((i + slip) / 40,
										(j + 40 - gap) / 40 - 1).isSolid(
										i + gap, j + gap) == false)
							i--;
						else if (Main.game.getCell((i + 40 - slip) / 40,
								(j + 40 - gap) / 40 - 1).isSolid(i + gap,
								j + gap) == false
								&& Main.game.getCell((i + gap) / 40,
										(j + 40 - gap) / 40 - 1).isSolid(
										i + gap, j + gap) == true)
							i++;
					}
				}
			}

			this.setLocation(i, j);

			try {

				Thread.sleep(0, 5);
			} catch (InterruptedException ex) {
				Logger.getLogger(Player.class.getName()).log(Level.SEVERE,
						null, ex);
			}

		}
		this.setIcon(Main.images.player[0][6]);
		Main.speaker.Play(Main.speaker.DIE);
		try {
			Thread.sleep(1000);
		} catch (InterruptedException ex) {
		}
		this.setVisible(false);
	}

}

import javax.swing.JLabel;

public class Cell extends JLabel {
	private int x;
	private int y;
	private int kind = 0;
	private int bombed = 0;
	private int food = -1;
	private int foodmode = 0;

	public boolean isSolid(int i, int j) {
		if (Math.abs(i - this.getX()) < 20 && Math.abs(j - this.getY()) < 20
				&& bombed == 1) {
			return false;
		} else if (bombed == 1 || kind != 0)
			return true;
		else
			return false;

	}

	public int getBombed() {
		return bombed;
	}

	public void setBombed(int bombed) {
		this.bombed = bombed;
	}

	public Cell(int r, int c, int k) {
		x = r;
		y = c;
		this.setSize(40, 40);
		this.setKind(k);
	}

	public int getKind() {
		return kind;
	}

	public void setKind(int k) {
		this.kind = k;
		this.setIcon(Main.images.cell[kind]);
		if (kind == 1) {
			int rnd = (int) (Math.random() * 8);
			if (rnd == 1)
				food = 0;
			else if (rnd == 3)
				food = 1;
			else if (rnd == 5)
				food = 2;
			else if (rnd == 7)
				food = 3;
			else
				food = -1;
		}
	}

	public int isFood() {
		if (foodmode == 1 && kind == 0)
			return 1;
		else
			return 0;
	}

	public int getFood() {
		return food;
	}

	public void breakBox() {
		if (this.kind == 1) {
			this.kind = 0;
			this.foodmode = 1;
			if (food != -1)
				this.setIcon(Main.images.food[food]);
			else
				eatFood();
		}
	}

	public void eatFood() {
		if (this.kind == 0 && this.foodmode == 1) {
			this.kind = 0;
			this.foodmode = 0;
			this.setIcon(Main.images.cell[kind]);
		}
	}
}

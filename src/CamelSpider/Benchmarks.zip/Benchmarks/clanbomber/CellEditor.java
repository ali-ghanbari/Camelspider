import java.awt.AWTEvent;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import javax.swing.JLabel;

public class CellEditor extends JLabel{
    private int k = 0;

    public void setK(int a){
        k = a;
        changePic();

    }

    public int getK(){
        return k;
    }

    public CellEditor(){
        k=0;
 
        this.enableEvents(AWTEvent.MOUSE_EVENT_MASK);
        this.setVisible(true);
        this.setSize(40, 40);
               changePic();
    }


    public void changePic(){
        this.setIcon(Main.images.cell[k]);
    }
    
    public void addk(){
            if(k==0)k=1;
            else if(k==1)k=2;
            else if(k==2){
                if(Main.me.has(0)==0){
                    k=3;
                    Main.me.setHas(0, 1);
                }
                else if(Main.me.has(1)==0){
                    k=4;
                    Main.me.setHas(1, 1);
                }
                else if(Main.me.has(2)==0){
                    k=5;
                    Main.me.setHas(2, 1);
                }
                else{
                    k=0;
                }

            }
            else if(k==3){
                Main.me.setHas(0, 0);
                if(Main.me.has(1)==0){
                    k=4;
                    Main.me.setHas(1, 1);
                }
                else if(Main.me.has(2)==0){
                    k=5;
                    Main.me.setHas(2, 1);
                }
                else{
                    k=0;
                }

            }
            else if(k==4){
                Main.me.setHas(1, 0);
                if(Main.me.has(2)==0){
                    k=5;
                    Main.me.setHas(2, 1);
                }
                else{
                    k=0;
                }

            }
            else if(k==5){
                Main.me.setHas(2, 0);
                k=0;


            }
            changePic();
    }


    @Override
    protected void processMouseEvent(MouseEvent e) {
             if (e.getID() == e.MOUSE_CLICKED)addk();

    super.processMouseEvent(e);

    }


}

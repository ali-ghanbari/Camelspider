import java.awt.AWTEvent;
import java.awt.event.MouseEvent;
import javax.swing.JLabel;
import org.omg.PortableInterceptor.SYSTEM_EXCEPTION;

public class MainButton extends JLabel {

	private int index;

	public MainButton(int index) {
		this.index = index;
		this.enableEvents(AWTEvent.MOUSE_EVENT_MASK);
		this.setIcon(Main.images.btn0[index]);
	}

	public void activate() {
		Main.mf.btn[Main.mf.getActiveBtn()].deactivate();
		this.setIcon(Main.images.btn1[index]);
		Main.mf.setActiveBtn(index);
	}

	public void deactivate() {
		this.setIcon(Main.images.btn0[index]);
	}

	public void press() {
		this.setIcon(Main.images.btn2[index]);

	}

	public void click() {

		press();

		if (index == 0) {
			Main.mp[0].setWins(0);
			Main.mp[1].setWins(0);
			Main.mp[2].setWins(0);
			Main.game.tt.end();
			Main.game = new Game(new Map(Main.mapnum));
			Main.game.setVisible(true);
			Main.mf.setVisible(false);
		}
		if (index == 1) {
			if (Main.start == 0)
				Main.game = new Game(new Map(Main.mapnum));
			Main.game.tt.ppp = 0;
			Main.game.setVisible(true);
			Main.mf.setVisible(false);
		}
		if (index == 2) {
			Main.op = new Options();
			Main.op.setVisible(true);
			Main.mf.setVisible(false);
		} else if (index == 3) {
			Main.me = new MapEditor();
			Main.me.setVisible(true);
			Main.mf.setVisible(false);
		}
		if (index == 4) {
			System.exit(1);
		}
		activate();

	}

	@Override
	protected void processMouseEvent(MouseEvent e) {
		if (e.getID() == e.MOUSE_EXITED)
			deactivate();
		if (e.getID() == e.MOUSE_ENTERED)
			activate();
		if (e.getID() == e.MOUSE_PRESSED)
			press();
		if (e.getID() == e.MOUSE_CLICKED)
			click();

		super.processMouseEvent(e);

	}

}

import java.awt.AWTEvent;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowEvent;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Options extends JFrame {
	private JPanel pnl = new JPanel();
	private Handler hhh = new Handler();
	private CharSelector[] cs = new CharSelector[3];
	private JTextField[] name = new JTextField[3];
	private ActiveSelector[] active = new ActiveSelector[3];
	private TeamSelector[] team = new TeamSelector[3];
	private PadSelector[] pad = new PadSelector[3];
	private JButton ok = new JButton();

	public Options() {
		pnl.setLayout(null);
		this.setLayout(null);

		this.getContentPane().setBackground(Color.BLACK);
		this.setUndecorated(true);
		Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
		pnl.setSize(20 * 40, 15 * 40);
		active[0] = new ActiveSelector();
		active[1] = new ActiveSelector();
		active[2] = new ActiveSelector();
		active[0].setLocation(40, 40);
		active[1].setLocation(40, 120);
		active[2].setLocation(40, 200);
		active[0].setK(Main.mp[0].active);
		active[1].setK(Main.mp[1].active);
		active[2].setK(Main.mp[2].active);
		// pnl.add(active[0]);
		// pnl.add(active[1]);
		// pnl.add(active[2]);
		name[0] = new JTextField();
		name[1] = new JTextField();
		name[2] = new JTextField();
		name[0].setLocation(100, 40);
		name[1].setLocation(100, 120);
		name[2].setLocation(100, 200);
		name[0].setSize(100, 40);
		name[1].setSize(100, 40);
		name[2].setSize(100, 40);
		name[0].setText(Main.mp[0].name);
		name[1].setText(Main.mp[1].name);
		name[2].setText(Main.mp[2].name);
		name[0].addKeyListener(hhh);
		name[1].addKeyListener(hhh);
		name[2].addKeyListener(hhh);
		pnl.add(name[0]);
		pnl.add(name[1]);
		pnl.add(name[2]);
		cs[0] = new CharSelector();
		cs[1] = new CharSelector();
		cs[2] = new CharSelector();
		cs[0].setLocation(220, 40);
		cs[1].setLocation(220, 120);
		cs[2].setLocation(220, 200);
		cs[0].setK(Main.mp[0].getCharacter());
		cs[1].setK(Main.mp[1].getCharacter());
		cs[2].setK(Main.mp[2].getCharacter());
		pnl.add(cs[0]);
		pnl.add(cs[1]);
		pnl.add(cs[2]);
		team[0] = new TeamSelector();
		team[1] = new TeamSelector();
		team[2] = new TeamSelector();
		team[0].setLocation(280, 40);
		team[1].setLocation(280, 120);
		team[2].setLocation(280, 200);
		team[0].setK(Main.mp[0].getGroup());
		team[1].setK(Main.mp[1].getGroup());
		team[2].setK(Main.mp[2].getGroup());
		team[0].setK(Main.mp[0].getGroup());
		pnl.add(team[0]);
		pnl.add(team[1]);
		pnl.add(team[2]);
		pad[0] = new PadSelector();
		pad[1] = new PadSelector();
		pad[2] = new PadSelector();
		pad[0].setLocation(340, 40);
		pad[1].setLocation(340, 120);
		pad[2].setLocation(340, 200);
		ok.setLocation(0, 560);
		ok.setSize(800, 40);
		ok.setText("OK");

		pnl.add(ok);
		ok.addKeyListener(hhh);
		ok.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				ok();
			}
		});
		if (Main.mp[0].getKeys(0) == 37)
			pad[0].setK(0);
		else if (Main.mp[0].getKeys(0) == 65)
			pad[0].setK(1);
		else if (Main.mp[0].getKeys(0) == 74)
			pad[0].setK(2);
		if (Main.mp[1].getKeys(0) == 37)
			pad[1].setK(0);
		else if (Main.mp[1].getKeys(0) == 65)
			pad[1].setK(1);
		else if (Main.mp[1].getKeys(0) == 74)
			pad[1].setK(2);
		if (Main.mp[2].getKeys(0) == 37)
			pad[2].setK(0);
		else if (Main.mp[2].getKeys(0) == 65)
			pad[2].setK(1);
		else if (Main.mp[2].getKeys(0) == 74)
			pad[2].setK(2);
		pnl.add(pad[0]);
		pnl.add(pad[1]);
		pnl.add(pad[2]);
		pnl.setLocation((d.width - pnl.getWidth()) / 2,
				(d.height - pnl.getHeight()) / 2);
		this.add(pnl);
		this.addKeyListener(hhh);
		this.setResizable(false);
		this.setSize(d);
	}

	public void ok() {
		Main.mp[0].active = active[0].getK();
		Main.mp[0].name = name[0].getText();
		Main.mp[0].setCharacter(cs[0].getK());
		Main.mp[0].setGroup(team[0].getK());
		Main.mp[1].active = active[1].getK();
		Main.mp[1].name = name[1].getText();
		Main.mp[1].setCharacter(cs[1].getK());
		Main.mp[1].setGroup(team[1].getK());
		Main.mp[2].active = active[2].getK();
		Main.mp[2].name = name[2].getText();
		Main.mp[2].setCharacter(cs[2].getK());
		Main.mp[2].setGroup(team[2].getK());
		int[] a = { 37, 39, 38, 40, 10 };
		int[] b = { 65, 68, 87, 83, 192 };
		int[] c = { 74, 76, 73, 75, 32 };
		if (pad[0].getK() == 0)
			Main.mp[0].setKeys(a);
		if (pad[0].getK() == 1)
			Main.mp[0].setKeys(b);
		if (pad[0].getK() == 2)
			Main.mp[0].setKeys(c);
		if (pad[1].getK() == 0)
			Main.mp[1].setKeys(a);
		if (pad[1].getK() == 1)
			Main.mp[1].setKeys(b);
		if (pad[1].getK() == 2)
			Main.mp[1].setKeys(c);
		if (pad[2].getK() == 0)
			Main.mp[2].setKeys(a);
		if (pad[2].getK() == 1)
			Main.mp[2].setKeys(b);
		if (pad[2].getK() == 2)
			Main.mp[2].setKeys(c);
		back();
	}

	public void back() {
		Main.mf.setVisible(true);
		this.dispose();
	}

	@Override
	protected void processEvent(AWTEvent e) {
		if (e.getID() == WindowEvent.WINDOW_CLOSING)
			Main.mf.setVisible(true);
		super.processEvent(e);
	}

	public class Handler implements KeyListener {

		public void keyTyped(KeyEvent e) {

		}

		public void keyPressed(KeyEvent e) {
			if (e.getKeyCode() == 27) {
				back();
			}
		}

		public void keyReleased(KeyEvent e) {
		}

	}
}

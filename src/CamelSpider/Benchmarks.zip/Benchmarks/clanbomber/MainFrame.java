import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class MainFrame extends JFrame {
	private int w = 407;
	private int h = 538;
	private int activeBtn = 0;
	private JLabel lbl = new JLabel();

	public JLabel getLbl() {
		return lbl;
	}

	MainButton btn[] = new MainButton[5];

	public int getActiveBtn() {
		return activeBtn;
	}

	public void setActiveBtn(int activeBtn) {
		this.activeBtn = activeBtn;
	}

	public MainFrame() {
		lbl.setLayout(null);
		this.setLayout(null);

		for (int i = 0; i < btn.length; i++) {
			btn[i] = new MainButton(i);
			btn[i].setLocation(130 - 16 * i, 105 + 75 * i);
			btn[i].setSize(200, 50);
			lbl.add(btn[i]);
		}

		Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
		this.setLocation(0, 0);
		this.getContentPane().setBackground(Color.BLACK);
		this.setUndecorated(true);
		this.setSize(d);
		lbl.setSize(w, h);
		lbl.setIcon(Main.images.NOTEBOOK);
		lbl.setLocation(d.width / 2 - w / 2, d.height / 2 - h / 2);
		this.add(lbl);
		this.addKeyListener(new MainHandler());
		this.setResizable(false);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setVisible(true);

	}

	private class MainHandler implements KeyListener {

		public void keyTyped(KeyEvent e) {

		}

		public void keyPressed(KeyEvent e) {

			if (e.getKeyCode() == KeyEvent.VK_DOWN) {
				btn[activeBtn].deactivate();
				if (activeBtn < btn.length - 1)
					activeBtn++;
				else
					activeBtn = 0;
				btn[activeBtn].activate();
			}
			if (e.getKeyCode() == KeyEvent.VK_UP) {
				btn[activeBtn].deactivate();
				if (activeBtn > 0)
					activeBtn--;
				else
					activeBtn = btn.length - 1;
				btn[activeBtn].activate();
			}
			if (e.getKeyCode() == KeyEvent.VK_ENTER) {
				btn[activeBtn].press();
			}

		}

		public void keyReleased(KeyEvent e) {
			if (e.getKeyCode() == KeyEvent.VK_ENTER) {
				btn[activeBtn].click();

			}
		}

	}

}

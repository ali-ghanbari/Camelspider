import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.logging.Level;
import java.util.logging.Logger;
import sun.audio.AudioPlayer;
import sun.audio.AudioStream;

public class Speaker {
	public void Play(URI fileName) {
		InputStream in = null;
		AudioStream as = null;
		try {
			in = new FileInputStream(new File(fileName));
		} catch (FileNotFoundException e) {
		}
		try {
			as = new AudioStream(in);
		} catch (IOException e) {
		}
		AudioPlayer.player.start(as);

	}

	public URI EXPLODE, WOW, DIE, TIME, PUTBOMB, CLAP;

	public Speaker() {
		try {
			EXPLODE = this.getClass().getResource("Sounds\\explode.wav")
					.toURI();
			WOW = this.getClass().getResource("Sounds\\wow.wav").toURI();
			DIE = this.getClass().getResource("Sounds\\die.wav").toURI();
			TIME = this.getClass().getResource("Sounds\\time.wav").toURI();
			PUTBOMB = this.getClass().getResource("Sounds\\putbomb.wav")
					.toURI();
			CLAP = this.getClass().getResource("Sounds\\clap.wav").toURI();
		} catch (URISyntaxException ex) {
		}
	}

}

import java.util.logging.Level;
import java.util.logging.Logger;
import sun.audio.AudioPlayer;

public class Time extends MyThread {
	int cc = 0;
	int EOP = 0;
	int aaa = 0;
	int www = 0;
	int ppp = 0;

	public Time() {
		cc = 0;
		EOP = 0;
	}

	public void end() {
		EOP = 1;
		aaa = 1;
	}

	@Override
	public void run() {
		try {
			Thread.sleep(1);
		} catch (InterruptedException ex) {
			Logger.getLogger(Time.class.getName()).log(Level.SEVERE, null, ex);
		}
		int a, b, c;
		cc = 0;
		while (EOP == 0) {

			if (cc == 300)
				EOP = 1;
			a = Main.game.getGroupIfAlive(0);
			b = Main.game.getGroupIfAlive(1);
			c = Main.game.getGroupIfAlive(2);
			if (a == -1 && b == c) {
				www = 1;
				END();
			} else if (b == -1 && a == c) {
				www = 1;
				END();
			} else if (c == -1 && a == b) {
				www = 1;
				END();
			} else if (a == -1 && b == -1) {
				www = 1;
				END();
			} else if (a == -1 && c == -1) {
				www = 1;
				END();
			} else if (b == -1 && c == -1) {
				www = 1;
				END();
			}
			Main.game.showTime(cc);
			if (ppp == 0)
				cc++;
			try {
				Thread.sleep(1000);
			} catch (InterruptedException ex) {
				Logger.getLogger(Time.class.getName()).log(Level.SEVERE, null,
						ex);
			}
		}
		if (aaa == 0 && www == 0) {
			Main.speaker.Play(Main.speaker.TIME);
			Main.game.kill(0);
			Main.game.kill(1);
			Main.game.kill(2);
			END();
		}
	}

	public void END() {

		EOP = 1;
		if (Main.game.isVisible() == true) {
			System.out.println(Main.game.player[0].getDead());
			System.out.println(Main.game.player[1].getDead());
			System.out.println(Main.game.player[2].getDead());
			if (Main.game.getGroupIfAlive(0) != -1) {
				if (Main.mp[0].getGroup() == Main.game.getGroupIfAlive(0))
					Main.mp[0].win();
				if (Main.mp[1].getGroup() == Main.game.getGroupIfAlive(0))
					Main.mp[1].win();
				if (Main.mp[2].getGroup() == Main.game.getGroupIfAlive(0))
					Main.mp[2].win();
			} else if (Main.game.getGroupIfAlive(1) != -1) {
				if (Main.mp[0].getGroup() == Main.game.getGroupIfAlive(1))
					Main.mp[0].win();
				if (Main.mp[1].getGroup() == Main.game.getGroupIfAlive(1))
					Main.mp[1].win();
				if (Main.mp[2].getGroup() == Main.game.getGroupIfAlive(1))
					Main.mp[2].win();
			} else if (Main.game.getGroupIfAlive(2) != -1) {
				if (Main.mp[0].getGroup() == Main.game.getGroupIfAlive(2))
					Main.mp[0].win();
				if (Main.mp[1].getGroup() == Main.game.getGroupIfAlive(2))
					Main.mp[1].win();
				if (Main.mp[2].getGroup() == Main.game.getGroupIfAlive(2))
					Main.mp[2].win();
			}
			Main.board = new Board();
			Main.board.setVisible(true);
			Main.game.setVisible(false);
		}
	}

}

import javax.swing.JLabel;

public class Fire extends JLabel {
	int on = 0;
	int kind = -1;

	public Fire() {
		this.setSize(470, 40);
		on = 0;
	}

	public int getOn() {
		return on;
	}

	public void setOn(int on, int k) {
		if (on == 1) {
			if (kind == 0 && k == 0)
				k = 0;
			else if (kind == 0 && k == 1)
				k = 0;
			else if (kind == 0 && k == 2)
				k = 0;
			else if (kind == 0 && k == 3)
				k = 0;
			else if (kind == 0 && k == 4)
				k = 8;
			else if (kind == 0 && k == 5)
				k = 8;
			else if (kind == 0 && k == 6)
				k = 8;
			else if (kind == 0 && k == 7)
				k = 8;
			else if (kind == 0 && k == 8)
				k = 8;

			else if (kind == 1 && k == 0)
				k = 0;
			else if (kind == 1 && k == 1)
				k = 1;
			else if (kind == 1 && k == 2)
				k = 0;
			else if (kind == 1 && k == 3)
				k = 0;
			else if (kind == 1 && k == 4)
				k = 8;
			else if (kind == 1 && k == 5)
				k = 8;
			else if (kind == 1 && k == 6)
				k = 8;
			else if (kind == 1 && k == 7)
				k = 8;
			else if (kind == 1 && k == 8)
				k = 8;

			else if (kind == 2 && k == 0)
				k = 0;
			else if (kind == 2 && k == 1)
				k = 0;
			else if (kind == 2 && k == 2)
				k = 0;
			else if (kind == 2 && k == 3)
				k = 0;
			else if (kind == 2 && k == 4)
				k = 8;
			else if (kind == 2 && k == 5)
				k = 8;
			else if (kind == 2 && k == 6)
				k = 8;
			else if (kind == 2 && k == 7)
				k = 8;
			else if (kind == 2 && k == 8)
				k = 8;

			else if (kind == 3 && k == 0)
				k = 0;
			else if (kind == 3 && k == 1)
				k = 0;
			else if (kind == 3 && k == 2)
				k = 0;
			else if (kind == 3 && k == 3)
				k = 3;
			else if (kind == 3 && k == 4)
				k = 8;
			else if (kind == 3 && k == 5)
				k = 8;
			else if (kind == 3 && k == 6)
				k = 8;
			else if (kind == 3 && k == 7)
				k = 8;
			else if (kind == 3 && k == 8)
				k = 8;

			else if (kind == 4 && k == 0)
				k = 8;
			else if (kind == 4 && k == 1)
				k = 8;
			else if (kind == 4 && k == 2)
				k = 8;
			else if (kind == 4 && k == 3)
				k = 8;
			else if (kind == 4 && k == 4)
				k = 4;
			else if (kind == 4 && k == 5)
				k = 4;
			else if (kind == 4 && k == 6)
				k = 4;
			else if (kind == 4 && k == 7)
				k = 4;
			else if (kind == 4 && k == 8)
				k = 8;

			else if (kind == 5 && k == 0)
				k = 8;
			else if (kind == 5 && k == 1)
				k = 8;
			else if (kind == 5 && k == 2)
				k = 8;
			else if (kind == 5 && k == 3)
				k = 8;
			else if (kind == 5 && k == 4)
				k = 4;
			else if (kind == 5 && k == 5)
				k = 5;
			else if (kind == 5 && k == 6)
				k = 4;
			else if (kind == 5 && k == 7)
				k = 4;
			else if (kind == 5 && k == 8)
				k = 8;

			else if (kind == 6 && k == 0)
				k = 8;
			else if (kind == 6 && k == 1)
				k = 8;
			else if (kind == 6 && k == 2)
				k = 8;
			else if (kind == 6 && k == 3)
				k = 8;
			else if (kind == 6 && k == 4)
				k = 4;
			else if (kind == 6 && k == 5)
				k = 4;
			else if (kind == 6 && k == 6)
				k = 4;
			else if (kind == 6 && k == 7)
				k = 4;
			else if (kind == 6 && k == 8)
				k = 8;

			else if (kind == 7 && k == 0)
				k = 8;
			else if (kind == 7 && k == 1)
				k = 8;
			else if (kind == 7 && k == 2)
				k = 8;
			else if (kind == 7 && k == 3)
				k = 8;
			else if (kind == 7 && k == 4)
				k = 4;
			else if (kind == 7 && k == 5)
				k = 4;
			else if (kind == 7 && k == 6)
				k = 4;
			else if (kind == 7 && k == 7)
				k = 7;
			else if (kind == 7 && k == 8)
				k = 8;

			else if (kind == 8 && k == 0)
				k = 8;
			else if (kind == 8 && k == 1)
				k = 8;
			else if (kind == 8 && k == 2)
				k = 8;
			else if (kind == 8 && k == 3)
				k = 8;
			else if (kind == 8 && k == 4)
				k = 8;
			else if (kind == 8 && k == 5)
				k = 8;
			else if (kind == 8 && k == 6)
				k = 8;
			else if (kind == 8 && k == 7)
				k = 8;
			else if (kind == 8 && k == 8)
				k = 8;

		}
		this.on = on;
		kind = k;
		if (on == 1) {
			this.setIcon(Main.images.fire[k]);
		} else {
			kind = -1;
			this.setIcon(null);
		}
	}

}

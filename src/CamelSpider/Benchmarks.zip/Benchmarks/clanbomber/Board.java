import java.awt.AWTEvent;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Board extends JDialog {
	private JPanel pnl = new JPanel();
	private JLabel team[] = new JLabel[3];
	private JLabel player[] = new JLabel[3];
	private JLabel wins[] = new JLabel[3];
	private JButton btn[] = new JButton[6];
	private JButton ok = new JButton();
	private int end = 0;

	public Board() {
		end = 0;
		pnl.setLayout(null);
		this.setLayout(null);
		team[0] = new JLabel();
		team[1] = new JLabel();
		team[2] = new JLabel();
		team[0].setLocation(40, 40);
		team[1].setLocation(40, 120);
		team[2].setLocation(40, 200);
		team[0].setSize(40, 40);
		team[1].setSize(40, 40);
		team[2].setSize(40, 40);
		team[0].setIcon(Main.images.team[0]);
		team[1].setIcon(Main.images.team[1]);
		team[2].setIcon(Main.images.team[2]);
		pnl.add(team[0]);
		pnl.add(team[1]);
		pnl.add(team[2]);
		player[0] = new JLabel();
		player[1] = new JLabel();
		player[2] = new JLabel();
		player[0].setSize(40, 40);
		player[1].setSize(40, 40);
		player[2].setSize(40, 40);
		player[0].setLocation(100, Main.mp[0].getGroup() * 80 + 40);
		player[1].setLocation(160, Main.mp[1].getGroup() * 80 + 40);
		player[2].setLocation(220, Main.mp[2].getGroup() * 80 + 40);
		player[0].setIcon(Main.images.player[Main.mp[0].getCharacter()][0]);
		player[1].setIcon(Main.images.player[Main.mp[1].getCharacter()][1]);
		player[2].setIcon(Main.images.player[Main.mp[2].getCharacter()][2]);
		pnl.add(player[0]);
		pnl.add(player[1]);
		pnl.add(player[2]);
		wins[0] = new JLabel();
		wins[1] = new JLabel();
		wins[2] = new JLabel();
		wins[0].setLocation(280, 40);
		wins[1].setLocation(280, 120);
		wins[2].setLocation(280, 200);
		wins[0].setSize(40, 40);
		wins[1].setSize(40, 40);
		wins[2].setSize(40, 40);
		if (Main.mp[0].getGroup() == 0)
			wins[0].setText(Main.mp[0].getWins() + "");
		if (Main.mp[0].getGroup() == 1)
			wins[1].setText(Main.mp[0].getWins() + "");
		if (Main.mp[0].getGroup() == 2)
			wins[2].setText(Main.mp[0].getWins() + "");
		if (Main.mp[1].getGroup() == 0)
			wins[0].setText(Main.mp[1].getWins() + "");
		if (Main.mp[1].getGroup() == 1)
			wins[1].setText(Main.mp[1].getWins() + "");
		if (Main.mp[1].getGroup() == 2)
			wins[2].setText(Main.mp[1].getWins() + "");
		if (Main.mp[2].getGroup() == 0)
			wins[0].setText(Main.mp[2].getWins() + "");
		if (Main.mp[2].getGroup() == 1)
			wins[1].setText(Main.mp[2].getWins() + "");
		if (Main.mp[2].getGroup() == 2)
			wins[2].setText(Main.mp[2].getWins() + "");
		if (Main.mp[0].getWins() == 10 || Main.mp[1].getWins() == 10
				|| Main.mp[2].getWins() == 10) {
			end = 1;
			Main.speaker.Play(Main.speaker.CLAP);
		}
		pnl.add(wins[0]);
		pnl.add(wins[1]);
		pnl.add(wins[2]);
		btn[0] = new JButton();
		btn[1] = new JButton();
		btn[2] = new JButton();
		btn[3] = new JButton();
		btn[4] = new JButton();
		btn[5] = new JButton();
		btn[0].setLocation(0, 360);
		btn[1].setLocation(0, 400);
		btn[2].setLocation(0, 440);
		btn[3].setLocation(0, 480);
		btn[4].setLocation(0, 520);
		btn[5].setLocation(0, 560);
		btn[0].setSize(800, 40);
		btn[1].setSize(800, 40);
		btn[2].setSize(800, 40);
		btn[3].setSize(800, 40);
		btn[4].setSize(800, 40);
		btn[5].setSize(800, 40);
		btn[0].setText("MAP 1");
		btn[1].setText("MAP 2");
		btn[2].setText("MAP 3");
		btn[3].setText("MAP 4");
		btn[4].setText("MAP 5");
		btn[5].setText("COSTUME MAP");
		btn[0].addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				load(1);
			}
		});
		btn[1].addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				load(2);
			}
		});
		btn[2].addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				load(3);
			}
		});
		btn[3].addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				load(4);
			}
		});
		btn[4].addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				load(5);
			}
		});
		btn[5].addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				load(6);
			}
		});
		if (end == 0) {
			pnl.add(btn[0]);
			pnl.add(btn[1]);
			pnl.add(btn[2]);
			pnl.add(btn[3]);
			pnl.add(btn[4]);
			pnl.add(btn[5]);
		}
		ok = new JButton();
		ok.setLocation(0, 560);
		ok.setSize(800, 40);
		ok.setText("End This Game");
		ok.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				Main.start = 0;
				Main.mf.setVisible(true);
				Main.board.setVisible(false);
			}
		});

		this.getContentPane().setBackground(Color.BLACK);
		this.setUndecorated(true);
		Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
		pnl.setSize(20 * 40, 15 * 40);
		pnl.setLocation((d.width - pnl.getWidth()) / 2,
				(d.height - pnl.getHeight()) / 2);
		this.add(pnl);
		this.setResizable(false);
		this.setSize(d);
	}

	public void load(int map) {
		Main.game.tt.end();
		Main.game = new Game(new Map(map));
		Main.game.setVisible(true);
		this.setVisible(false);
	}

	public void back() {
		Main.mf.setVisible(true);
		this.dispose();
	}

	protected void processEvent(AWTEvent e) {
		if (e.getID() == WindowEvent.WINDOW_CLOSING)
			Main.game.setVisible(true);
		super.processEvent(e);
	}

}

public class MPlayer {
	private int keys[] = new int[5];
	private int index;
	private int character = 0;
	private int group = 0;
	private int wins;
	public String name = "";
	public int active = 1;

	public int getCharacter() {
		return character;
	}

	public void setCharacter(int character) {
		this.character = character;
	}

	public int getGroup() {
		return group;
	}

	public void setGroup(int group) {
		this.group = group;
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	public int getKeys(int o) {
		return keys[o];
	}

	public void setKeys(int[] keys) {
		this.keys = keys;
	}

	public int getWins() {
		return wins;
	}

	public void setWins(int wins) {
		this.wins = wins;
	}

	public void win() {
		wins++;
	}

	public MPlayer(int r, int l, int u, int d, int b, int index, int chara,
			int group, String s, int a) {
		keys[0] = r;
		keys[1] = l;
		keys[2] = u;
		keys[3] = d;
		keys[4] = b;
		character = chara;
		this.index = index;
		this.group = group;
		name = s;
		active = a;
	}

}

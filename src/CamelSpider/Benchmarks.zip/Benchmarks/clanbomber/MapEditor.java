import java.awt.AWTEvent;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class MapEditor extends JFrame {
	private int has[] = new int[3];

	public int has(int a) {
		return has[a];
	}

	public void setHas(int a, int b) {
		has[a] = b;
	}

	private CellEditor cell[][] = new CellEditor[20][14];
	private JPanel pnl = new JPanel();
	private JButton save = new JButton();
	private JButton load = new JButton();
	private Handler handler = new Handler();

	public MapEditor() {
		pnl.setLayout(null);
		this.setLayout(null);
		for (int i = 0; i < 20; i++) {
			for (int j = 0; j < 14; j++) {
				cell[i][j] = new CellEditor();
				cell[i][j].setK(1);
				cell[i][j].setLocation(40 * i, 40 + 40 * j);
				pnl.add(cell[i][j], -1);
			}
		}
		for (int i = 0; i < 20; i++) {
			cell[i][0].setK(2);
			cell[i][13].setK(2);
		}
		for (int j = 0; j < 14; j++) {
			cell[0][j].setK(2);
			cell[19][j].setK(2);
		}
		this.addKeyListener(handler);
		save.setLocation(0, 0);
		save.setSize(400, 40);
		save.setText("Save as costum map");
		load.setLocation(400, 0);
		load.setSize(400, 40);
		load.setText("Load costum map");
		pnl.add(save);
		pnl.add(load);
		save.addKeyListener(handler);
		load.addKeyListener(handler);
		save.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				SaveMap();
			}
		});
		load.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				loadMap();
			}
		});

		this.getContentPane().setBackground(Color.BLACK);
		this.setUndecorated(true);
		Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
		pnl.setSize(20 * 40, 15 * 40);
		pnl.setLocation((d.width - pnl.getWidth()) / 2,
				(d.height - pnl.getHeight()) / 2);
		this.add(pnl);
		this.setSize(d);
		this.setResizable(false);

	}

	private File file;

	public void back() {
		Main.mf.setVisible(true);
		this.dispose();
	}

	public void SaveMap() {

		try {
			file = new File(this.getClass().getResource("Maps\\006.map")
					.toURI());
		} catch (URISyntaxException ex) {
			Logger.getLogger(MapEditor.class.getName()).log(Level.SEVERE, null,
					ex);
		}
		FileOutputStream fis = null;
		try {
			fis = new FileOutputStream(file);
		} catch (FileNotFoundException ex) {
			Logger.getLogger(Map.class.getName()).log(Level.SEVERE, null, ex);
		}

		try {
			for (int j = 0; j < 14; j++) {
				for (int i = 0; i < 20; i++) {
					fis.write(cell[i][j].getK() + '0');
				}
			}
		} catch (IOException ex) {
			Logger.getLogger(Map.class.getName()).log(Level.SEVERE, null, ex);
		}

	}

	public void loadMap() {

		try {
			file = new File(this.getClass().getResource("Maps\\006.map")
					.toURI());
		} catch (URISyntaxException ex) {
			Logger.getLogger(MapEditor.class.getName()).log(Level.SEVERE, null,
					ex);
		}
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(file);
		} catch (FileNotFoundException ex) {
			Logger.getLogger(Map.class.getName()).log(Level.SEVERE, null, ex);
		}

		try {
			for (int j = 0; j < 14; j++) {
				for (int i = 0; i < 20; i++) {
					char b = (char) (fis.read());
					String a = "" + b;
					cell[i][j].setK(Integer.parseInt(a));
					if (cell[i][j].getK() == 3)
						has[0] = 1;
					if (cell[i][j].getK() == 4)
						has[1] = 1;
					if (cell[i][j].getK() == 5)
						has[2] = 1;
				}
			}
		} catch (IOException ex) {
			Logger.getLogger(Map.class.getName()).log(Level.SEVERE, null, ex);
		}

	}

	@Override
	protected void processEvent(AWTEvent e) {
		if (e.getID() == WindowEvent.WINDOW_CLOSING)
			Main.mf.setVisible(true);
		super.processEvent(e);
	}

	public class Handler implements KeyListener {

		public void keyTyped(KeyEvent e) {

		}

		public void keyPressed(KeyEvent e) {
			if (e.getKeyCode() == 27) {
				back();
			}
		}

		public void keyReleased(KeyEvent e) {
		}

	}

}

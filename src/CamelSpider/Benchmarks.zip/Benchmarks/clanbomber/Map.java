import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.URISyntaxException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Map {
	private String name = "";
	public int cell[][] = new int[20][14];

	public Map(int a) {
		try {
			loadMap(new File(this.getClass()
					.getResource("Maps\\00" + a + ".map").toURI()));

		} catch (URISyntaxException ex) {
			Logger.getLogger(Map.class.getName()).log(Level.SEVERE, null, ex);
		}

	}

	public void loadMap(File file) {
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(file);
		} catch (FileNotFoundException ex) {
			Logger.getLogger(Map.class.getName()).log(Level.SEVERE, null, ex);
		}

		try {
			for (int j = 0; j < 14; j++) {
				for (int i = 0; i < 20; i++) {
					char b = (char) (fis.read());
					String a = "" + b;
					cell[i][j] = Integer.parseInt(a);
				}
			}
		} catch (IOException ex) {
			Logger.getLogger(Map.class.getName()).log(Level.SEVERE, null, ex);
		}

	}
}

import java.awt.AWTEvent;
import java.awt.Color;
import java.awt.event.MouseEvent;
import javax.swing.JLabel;

public class ActiveSelector extends JLabel {
	private int k = 0;

	public void setK(int a) {
		k = a;
		changePic();

	}

	public int getK() {
		return k;
	}

	public ActiveSelector() {
		k = 0;

		this.enableEvents(AWTEvent.MOUSE_EVENT_MASK);
		this.setVisible(true);
		this.setBorder(javax.swing.BorderFactory.createLineBorder(Color.BLACK,
				2));
		this.setSize(40, 40);
		changePic();
	}

	public void changePic() {
		this.setIcon(Main.images.active[k]);
	}

	public void addk() {
		k++;
		if (k == 2)
			k = 0;
		changePic();
	}

	protected void processMouseEvent(MouseEvent e) {
		if (e.getID() == e.MOUSE_CLICKED)
			addk();

		super.processMouseEvent(e);

	}

}

import java.awt.AWTEvent;
import java.awt.Color;
import java.awt.event.MouseEvent;
import javax.swing.JLabel;

public class TeamSelector extends JLabel {
	private int k = 0;

	public void setK(int a) {
		k = a;
		changePic();

	}

	public int getK() {
		return k;
	}

	public TeamSelector() {
		k = 0;

		this.enableEvents(AWTEvent.MOUSE_EVENT_MASK);
		this.setVisible(true);
		this.setBorder(javax.swing.BorderFactory.createLineBorder(Color.BLACK,
				2));
		this.setSize(40, 40);
		changePic();
	}

	public void changePic() {
		this.setIcon(Main.images.team[k]);
	}

	public void addk() {
		k++;
		if (k == 3)
			k = 0;
		changePic();
	}

	@Override
	protected void processMouseEvent(MouseEvent e) {
		if (e.getID() == e.MOUSE_CLICKED)
			addk();

		super.processMouseEvent(e);

	}
}

import sun.audio.AudioPlayer;

public class Main {
	public static MainFrame mf;
	public static Images images = new Images();;
	public static Game game;
	public static MapEditor me = new MapEditor();
	public static Speaker speaker = new Speaker();
	public static MPlayer mp[] = new MPlayer[3];
	public static int mapnum = 1;
	public static Options op;
	public static int start = 0;
	public static Board board;

	public static void main(String[] args) {
		mp[0] = new MPlayer(37, 39, 38, 40, 10, 0, 0, 0, "Player1", 1);
		mp[1] = new MPlayer(65, 68, 87, 83, 192, 1, 1, 1, "Player2", 1);
		mp[2] = new MPlayer(74, 76, 73, 75, 32, 2, 2, 2, "Player3", 1);
		game = new Game(new Map(Main.mapnum));
		board = new Board();
		op = new Options();
		mf = new MainFrame();
	}

}

import java.awt.AWTEvent;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Game extends JDialog {
	private JPanel pnl = new JPanel();
	private Cell cell[][] = new Cell[20][14];
	private Fire fire[][] = new Fire[20][14];
	public Time tt;

	public Fire getFire(int i, int j) {
		return fire[i][j];
	}

	public Player player[] = new Player[3];
	private Thread[] thread = new Thread[3];
	private Handler handler = new Handler();
	private Map map;
	private JLabel time;

	public int getGroupIfAlive(int p) {
		if (player[p].getDead() == 0)
			return player[p].getGroup();
		else
			return -1;
	}

	public void kill(int p) {
		player[p].setDead(1);
	}

	public void showTime(int t) {
		time.setText("  " + (int) (300 - t));
	}

	public boolean playerIsHere(int index, int x, int y) {
		int i, j;
		i = player[index].getX();
		j = player[index].getY();

		if (x == ((i + 20) / 40) && y == ((j + 20) / 40) - 1) {
			return true;
		} else
			return false;
	}

	public void setCellBombed(int value, int i, int j) {
		cell[i][j].setBombed(value);
	}

	public void setFire(int i, int j, int k) {
		fire[i][j].setOn(1, k);
	}

	public void clearFire(int i, int j) {
		fire[i][j].setOn(0, 8);
	}

	public Cell getCell(int x, int y) {
		return cell[x][y];
	}

	public void addPlayerBomb(int index) {
		player[index].addBomb();
	}

	public void placeBomb(Bomb b) {
		pnl.add(b, 3);
	}

	int x0 = 0, x1 = 0, x2 = 0;
	int y0 = 0, y1 = 0, y2 = 0;

	public Game(Map m) {
		Main.start = 1;
		this.setLayout(null);
		pnl.setLayout(null);
		map = m;
		for (int i = 0; i < 20; i++) {
			for (int j = 0; j < 14; j++) {
				if (map.cell[i][j] > 2) {
					cell[i][j] = new Cell(i, j, 0);
					if (map.cell[i][j] == 3) {
						x0 = i;
						y0 = j;
					}
					if (map.cell[i][j] == 4) {
						x1 = i;
						y1 = j;
					}
					if (map.cell[i][j] == 5) {
						x2 = i;
						y2 = j;
					}
				} else
					cell[i][j] = new Cell(i, j, map.cell[i][j]);
				cell[i][j].setLocation(40 * i, 40 + 40 * j);
				pnl.add(cell[i][j], -1);
			}
		}
		for (int i = 0; i < 20; i++) {
			for (int j = 0; j < 14; j++) {
				fire[i][j] = new Fire();
				fire[i][j].setLocation(40 * i, 40 + 40 * j);
				pnl.add(fire[i][j], 0);
			}
		}
		time = new JLabel();
		time.setSize(100, 40);
		time.setText("TIME:");
		time.setOpaque(true);
		time.setLocation(40, 0);
		JLabel clock = new JLabel(Main.images.TIME);
		clock.setSize(40, 40);
		clock.setLocation(0, 0);
		pnl.add(time);
		pnl.add(clock);
		this.getContentPane().setBackground(Color.BLACK);
		this.setUndecorated(true);
		this.addKeyListener(handler);
		Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
		this.setSize(d);
		pnl.setSize(20 * 40, 15 * 40);
		pnl.setLocation((d.width - pnl.getWidth()) / 2,
				(d.height - pnl.getHeight()) / 2);
		this.add(pnl);
		this.setResizable(false);

		player[0] = new Player(Main.mp[0].getKeys(0), Main.mp[0].getKeys(1),
				Main.mp[0].getKeys(2), Main.mp[0].getKeys(3),
				Main.mp[0].getKeys(4), Main.mp[0].getIndex(),
				Main.mp[0].getCharacter(), Main.mp[0].getGroup());
		player[1] = new Player(Main.mp[1].getKeys(0), Main.mp[1].getKeys(1),
				Main.mp[1].getKeys(2), Main.mp[1].getKeys(3),
				Main.mp[1].getKeys(4), Main.mp[1].getIndex(),
				Main.mp[1].getCharacter(), Main.mp[1].getGroup());
		player[2] = new Player(Main.mp[2].getKeys(0), Main.mp[2].getKeys(1),
				Main.mp[2].getKeys(2), Main.mp[2].getKeys(3),
				Main.mp[2].getKeys(4), Main.mp[2].getIndex(),
				Main.mp[2].getCharacter(), Main.mp[2].getGroup());
		tt = new Time();
		// if(Main.mp[0].active==0)player[0].setVisible(false);
		// if(Main.mp[1].active==0)player[0].setVisible(false);
		// if(Main.mp[2].active==0)player[0].setVisible(false);

		for (int i = 0; i < 3; i++) {
			pnl.add(player[i], 1);
			player[0].setLocation(x0 * 40, (y0 + 1) * 40);
			player[1].setLocation(x1 * 40, (y1 + 1) * 40);
			player[2].setLocation(x2 * 40, (y2 + 1) * 40);
			// if(Main.mp[i].active==1)
			thread[i] = new MyThread(player[i]);
		}

		// if(Main.mp[0].active==1)
		thread[0].start();
		// if(Main.mp[1].active==1)
		thread[1].start();
		// if(Main.mp[2].active==1)
		thread[2].start();
		tt.start();
	}

	@Override
	protected void processEvent(AWTEvent e) {
		if (e.getID() == WindowEvent.WINDOW_CLOSING)
			back();
		super.processEvent(e);
	}

	public void back() {
		this.tt.ppp = 1;
		this.setVisible(false);
		Main.mf.setVisible(true);
	}

	public class Handler implements KeyListener {

		public void keyTyped(KeyEvent e) {

		}

		public void keyPressed(KeyEvent e) {
			for (int i = 0; i < 3; i++) {
				if (e.getKeyCode() == player[i].getKeys(0)
						|| e.getKeyCode() == player[i].getKeys(1)
						|| e.getKeyCode() == player[i].getKeys(2)
						|| e.getKeyCode() == player[i].getKeys(3))
					player[i].setKey(e.getKeyCode());
				if (e.getKeyCode() == player[i].getKeys(4))
					player[i].setBomb(1);

			}
			if (e.getKeyCode() == 27) {
				back();
			}
		}

		public void keyReleased(KeyEvent e) {
			for (int i = 0; i < 3; i++) {
				if (player[i].getKey() == e.getKeyCode())
					player[i].setKey(0);
			}

		}

	}
}

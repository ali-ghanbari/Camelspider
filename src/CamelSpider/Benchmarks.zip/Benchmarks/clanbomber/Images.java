import javax.swing.ImageIcon;

public class Images {
	private int btns = 5;
	public ImageIcon NOTEBOOK = new ImageIcon(this.getClass().getResource(
			"Images\\main.png"));
	public ImageIcon TIME = new ImageIcon(this.getClass().getResource(
			"Images\\TIME.png"));
	public ImageIcon btn0[] = new ImageIcon[btns];
	public ImageIcon btn1[] = new ImageIcon[btns];
	public ImageIcon btn2[] = new ImageIcon[btns];
	public ImageIcon player[][] = new ImageIcon[4][7];
	public ImageIcon[] cell = new ImageIcon[7];
	public ImageIcon[] fire = new ImageIcon[9];
	public ImageIcon[] food = new ImageIcon[4];
	public ImageIcon[] team = new ImageIcon[3];
	public ImageIcon[] pad = new ImageIcon[3];
	public ImageIcon[] active = new ImageIcon[2];

	public Images() {
		for (int i = 0; i < btns; i++) {
			btn0[i] = new ImageIcon(this.getClass().getResource(
					"Images\\0" + i + ".png"));
			btn1[i] = new ImageIcon(this.getClass().getResource(
					"Images\\1" + i + ".png"));
			btn2[i] = new ImageIcon(this.getClass().getResource(
					"Images\\2" + i + ".png"));
		}
		for (int i = 0; i < player.length; i++) {
			player[i][0] = new ImageIcon(
					(this.getClass().getResource("Images\\p" + i + "0.png")));
			player[i][1] = new ImageIcon(
					(this.getClass().getResource("Images\\p" + i + "1.png")));
			player[i][2] = new ImageIcon(
					(this.getClass().getResource("Images\\p" + i + "2.png")));
			player[i][3] = new ImageIcon(
					(this.getClass().getResource("Images\\p" + i + "3.png")));
			player[i][4] = new ImageIcon(
					(this.getClass().getResource("Images\\p" + i + "4.png")));
			player[i][5] = new ImageIcon(
					(this.getClass().getResource("Images\\p" + i + "5.png")));
			player[i][6] = new ImageIcon(
					(this.getClass().getResource("Images\\p" + i + "6.png")));
		}

		fire[0] = new ImageIcon(this.getClass().getResource("Images\\fh.png"));
		fire[1] = new ImageIcon(this.getClass().getResource("Images\\fr.png"));
		fire[2] = new ImageIcon(this.getClass().getResource("Images\\fh.png"));
		fire[3] = new ImageIcon(this.getClass().getResource("Images\\fl.png"));
		fire[4] = new ImageIcon(this.getClass().getResource("Images\\fv.png"));
		fire[5] = new ImageIcon(this.getClass().getResource("Images\\fu.png"));
		fire[6] = new ImageIcon(this.getClass().getResource("Images\\fv.png"));
		fire[7] = new ImageIcon(this.getClass().getResource("Images\\fd.png"));
		fire[8] = new ImageIcon(this.getClass().getResource("Images\\ft.png"));

		food[0] = new ImageIcon(this.getClass()
				.getResource("Images\\food0.png"));
		food[1] = new ImageIcon(this.getClass()
				.getResource("Images\\food1.png"));
		food[2] = new ImageIcon(this.getClass()
				.getResource("Images\\food2.png"));
		food[3] = new ImageIcon(this.getClass()
				.getResource("Images\\food3.png"));

		cell[0] = new ImageIcon((this.getClass().getResource("Images\\g.png")));
		cell[1] = new ImageIcon((this.getClass().getResource("Images\\b.png")));
		cell[2] = new ImageIcon((this.getClass().getResource("Images\\w.png")));
		cell[3] = new ImageIcon((this.getClass().getResource("Images\\1.png")));
		cell[4] = new ImageIcon((this.getClass().getResource("Images\\2.png")));
		cell[5] = new ImageIcon((this.getClass().getResource("Images\\3.png")));

		team[0] = new ImageIcon(
				(this.getClass().getResource("Images\\team0.png")));
		team[1] = new ImageIcon(
				(this.getClass().getResource("Images\\team1.png")));
		team[2] = new ImageIcon(
				(this.getClass().getResource("Images\\team2.png")));

		pad[0] = new ImageIcon(
				(this.getClass().getResource("Images\\pad0.png")));
		pad[1] = new ImageIcon(
				(this.getClass().getResource("Images\\pad1.png")));
		pad[2] = new ImageIcon(
				(this.getClass().getResource("Images\\pad2.png")));

		active[0] = new ImageIcon(
				(this.getClass().getResource("Images\\active0.png")));
		active[1] = new ImageIcon(
				(this.getClass().getResource("Images\\active1.png")));

	}

}

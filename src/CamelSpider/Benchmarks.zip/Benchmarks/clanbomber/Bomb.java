import java.util.logging.Level;
import javax.swing.JLabel;

public class Bomb extends JLabel implements MyRunnable {
	private int power = 1;
	private int exploded = 0;
	private int dead = 0;
	private int c;
	private int cc;
	private int index;
	private int rc, lc, dc, uc;
	private int character = 0;
	private int key = 0;
	private int gap = 1;
	private int slip = 2;
	private int sc = 0;
	private int speed = 10;
	private int aaa = 0;

	public void setKey(int k) {
		key = k;
	}

	public Bomb(int p, int index, int chara) {
		power = p;
		this.index = index;
		this.setSize(40, 40);
		this.setLocation(0, 0);
		this.setIcon(Main.images.player[character][4]);
		character = chara;
	}

	public void run() {

		int i, j;
		c = 0;
		cc = 0;

		while (exploded == 0) {

			if (Main.game.tt.aaa == 1) {
				exploded = 1;
				dead = 1;
				aaa = 1;
			}
			i = this.getX();
			j = this.getY();

			sc++;
			if (sc == (17 - speed))
				sc = 0;

			Main.game.setCellBombed(0, ((i + 20) / 40), ((j + 20) / 40) - 1);
			for (int o = 0; o < 3; o++) {
				if (Main.game.player[o].getKick() == 1) {
					if ((Main.game.player[o].getX()) == i + 40 - 1
							&& (Main.game.player[o].getY() - 20) / 40 == j / 40 - 1
							&& Main.game.player[o].getKey() == Main.game.player[o]
									.getKeys(0))
						key = 1;
					else if ((Main.game.player[o].getX()) + 40 == i + 1
							&& (Main.game.player[o].getY() - 20) / 40 == j / 40 - 1
							&& Main.game.player[o].getKey() == Main.game.player[o]
									.getKeys(1))
						key = 2;
					else if ((Main.game.player[o].getX() + 20) / 40 == i / 40
							&& (Main.game.player[o].getY()) == j + 40 + 1
							&& Main.game.player[o].getKey() == Main.game.player[o]
									.getKeys(2))
						key = 3;
					else if ((Main.game.player[o].getX() + 20) / 40 == i / 40
							&& (Main.game.player[o].getY()) + 40 == j + 1
							&& Main.game.player[o].getKey() == Main.game.player[o]
									.getKeys(3))
						key = 4;
				}
			}
			if (key == 1 && sc == 0) {
				if (i > 0) {
					if (Main.game.getCell((i + gap - 1) / 40,
							(j + 40 - gap) / 40 - 1).isSolid(i + gap, j + gap) == false
							&& Main.game.getCell((i + gap - 1) / 40,
									(j + gap) / 40 - 1).isSolid(i + gap,
									j + gap) == false)
						i--;
					else {
						i++;
						key = 0;
					}
				}
			} else if (key == 2 && sc == 0) {
				if (i < 760) {
					if (Main.game.getCell((i + 40 - gap) / 40,
							(j + 40 - gap) / 40 - 1).isSolid(i + gap, j + gap) == false
							&& Main.game.getCell((i + 40 - gap) / 40,
									(j + gap) / 40 - 1).isSolid(i + gap,
									j + gap) == false)
						i++;
					else {
						i--;
						key = 0;
					}
				}
			} else if (key == 3 && sc == 0) {
				if (j > 40) {
					if (Main.game.getCell((i + 40 - gap) / 40,
							(j - gap) / 40 - 1).isSolid(i + gap, j + gap) == false
							&& Main.game.getCell((i + gap) / 40,
									(j - gap) / 40 - 1).isSolid(i + gap,
									j + gap) == false)
						j--;
					else {
						j++;
						key = 0;
					}
				}
			} else if (key == 4 && sc == 0) {
				if (j < 560) {
					if (Main.game.getCell((i + 40 - gap) / 40,
							(j + 40 - gap) / 40 - 1).isSolid(i + gap, j + gap) == false
							&& Main.game.getCell((i + gap) / 40,
									(j + 40 - gap) / 40 - 1).isSolid(i + gap,
									j + gap) == false)
						j++;
					else {
						j--;
						key = 0;
					}
				}
			}

			Main.game.setCellBombed(1, ((i + 20) / 40), ((j + 20) / 40) - 1);
			this.setLocation(i, j);
			if (c % 500 == 0)
				this.setIcon(Main.images.player[character][4]);
			else if (c % 250 == 0)
				this.setIcon(Main.images.player[character][5]);
			if (Main.game.getFire(((i + 20) / 40), ((j + 20) / 40) - 1).getOn() == 1)
				c = 2999;
			c++;
			if (c == 3000) {
				exploded = 1;
				Main.game.addPlayerBomb(index);
				Main.game
						.setCellBombed(0, ((i + 20) / 40), ((j + 20) / 40) - 1);
			}
			try {

				Thread.sleep(1);
			} catch (InterruptedException ex) {

			}

		}
		if (aaa == 0) {
			Main.speaker.Play(Main.speaker.EXPLODE);
			this.setIcon(null);
			i = this.getX() / 40;
			j = this.getY() / 40 - 1;
			int f = 0;
			int fc = 0;
			while (f == 0) {

				if (Main.game.getCell(i + fc, j).getKind() == 1
						|| Main.game.getCell(i + fc, j).isFood() == 1) {
					f = 1;
					Main.game.setFire(i + fc, j, 1);
				} else if (fc == power) {
					f = 1;
					Main.game.setFire(i + fc, j, 1);
				} else if (Main.game.getCell(i + fc + 1, j).getKind() == 2) {
					f = 1;
					Main.game.setFire(i + fc, j, 0);
				} else if (Main.game.getCell(i + fc, j).getBombed() == 1) {
					f = 1;
					Main.game.setFire(i + fc, j, 1);
				} else if (Main.game.getCell(i + fc, j).getKind() == 0)
					Main.game.setFire(i + fc, j, 0);
				fc++;
			}
			fc--;
			rc = fc;
			f = 0;
			fc = 0;
			while (f == 0) {

				if (Main.game.getCell(i - fc, j).getKind() == 1
						|| Main.game.getCell(i - fc, j).isFood() == 1) {
					f = 1;
					Main.game.setFire(i - fc, j, 3);
				} else if (fc == power) {
					f = 1;
					Main.game.setFire(i - fc, j, 3);
				} else if (Main.game.getCell(i - fc - 1, j).getKind() == 2) {
					f = 1;
					Main.game.setFire(i - fc, j, 2);
				} else if (Main.game.getCell(i - fc, j).getBombed() == 1) {
					f = 1;
					Main.game.setFire(i - fc, j, 3);
				} else if (Main.game.getCell(i - fc, j).getKind() == 0)
					Main.game.setFire(i - fc, j, 2);
				fc++;
			}
			fc--;
			lc = fc;
			f = 0;
			fc = 0;
			while (f == 0) {
				if (Main.game.getCell(i, j + fc).getKind() == 1
						|| Main.game.getCell(i, j + fc).isFood() == 1) {
					f = 1;
					Main.game.setFire(i, j + fc, 7);
				} else if (fc == power) {
					f = 1;
					Main.game.setFire(i, j + fc, 7);
				} else if (Main.game.getCell(i, j + fc + 1).getKind() == 2) {
					f = 1;
					Main.game.setFire(i, j + fc, 6);
				} else if (Main.game.getCell(i, j + fc).getBombed() == 1) {
					f = 1;
					Main.game.setFire(i, j + fc, 3);
				} else if (Main.game.getCell(i, j + fc).getKind() == 0)
					Main.game.setFire(i, j + fc, 6);
				fc++;
			}
			fc--;
			dc = fc;
			f = 0;
			fc = 0;
			while (f == 0) {

				if (Main.game.getCell(i, j - fc).getKind() == 1
						|| Main.game.getCell(i, j - fc).isFood() == 1) {
					f = 1;
					Main.game.setFire(i, j - fc, 5);
				} else if (fc == power) {
					f = 1;
					Main.game.setFire(i, j - fc, 5);
				} else if (Main.game.getCell(i, j - fc - 1).getKind() == 2) {
					f = 1;
					Main.game.setFire(i, j - fc, 4);
				} else if (Main.game.getCell(i, j - fc).getBombed() == 1) {
					f = 1;
					Main.game.setFire(i, j - fc, 3);
				} else if (Main.game.getCell(i, j - fc).getKind() == 0)
					Main.game.setFire(i, j - fc, 4);
				fc++;
			}
			fc--;
			uc = fc;
			Main.game.setFire(i, j, 8);
		}
		cc = 0;
		while (dead == 0) {
			if (Main.game.tt.isAlive() == false) {
				dead = 1;
			}
			i = this.getX() / 40;
			j = this.getY() / 40 - 1;
			if (cc < 499) {
				for (int o = 1; o < rc; o++)
					Main.game.setFire(i + o, j, 0);
				Main.game.setFire(i + rc, j, 1);
				for (int o = 1; o < lc; o++)
					Main.game.setFire(i - o, j, 2);
				Main.game.setFire(i - lc, j, 3);
				for (int o = 1; o < uc; o++)
					Main.game.setFire(i, j - o, 4);
				Main.game.setFire(i, j - uc, 5);
				for (int o = 1; o < dc; o++)
					Main.game.setFire(i, j + o, 6);
				Main.game.setFire(i, j + dc, 7);
				Main.game.setFire(i, j, 8);
			} else if (cc == 499) {
				Main.game.clearFire(i, j);
				for (int o = 1; o < rc + 1; o++)
					Main.game.clearFire(i + o, j);
				for (int o = 1; o < lc + 1; o++)
					Main.game.clearFire(i - o, j);
				for (int o = 1; o < uc + 1; o++)
					Main.game.clearFire(i, j - o);
				for (int o = 1; o < dc + 1; o++)
					Main.game.clearFire(i, j + o);
				Main.game.getCell(i + rc, j).eatFood();
				Main.game.getCell(i - lc, j).eatFood();
				Main.game.getCell(i, j + dc).eatFood();
				Main.game.getCell(i, j - uc).eatFood();
				Main.game.getCell(i + rc, j).breakBox();
				Main.game.getCell(i - lc, j).breakBox();
				Main.game.getCell(i, j + dc).breakBox();
				Main.game.getCell(i, j - uc).breakBox();
			}
			cc++;
			if (cc == 500)
				dead = 1;
			try {

				Thread.sleep(1);
			} catch (InterruptedException ex) {

			}

		}

	}

}

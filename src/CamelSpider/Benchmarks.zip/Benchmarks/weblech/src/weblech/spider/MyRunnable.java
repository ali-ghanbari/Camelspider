package weblech.spider;

public interface MyRunnable {
	abstract public void run();
}

package weblech.spider;

public class MyThread extends Thread {
	private MyRunnable r;
	private String name;

	public MyThread() {
		r = null;
	}

	public MyThread(MyRunnable r) {
		this.r = r;
	}

	public MyThread(MyRunnable r, String name) {
		this.r = r;
		this.name = name;
	}

	public void run () {
		if(r != null)		
			r.run();
	}
}

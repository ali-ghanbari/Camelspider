Controls the Spider and gives graphical feedback about download progress

Compiled class files go here during a build.

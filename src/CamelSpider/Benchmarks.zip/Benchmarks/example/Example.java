class Shared {
	public int i;

	Shared() {
		i = 0;
	}
}

public class Example extends Thread {
	static Shared s_field;
	static Object lock_ = new Object();

	public static void main(String[] args) throws InterruptedException {
		Shared s_local = new Shared();
		s_local.i++;
		s_field = s_local;
		s_field.i++;
		Thread t = new Example();
		t.start();
		synchronized (lock_) {
			s_field.i++;
		}
	}

	public void run() {
		synchronized (lock_) {
			s_field.i++;
		}
	}
}
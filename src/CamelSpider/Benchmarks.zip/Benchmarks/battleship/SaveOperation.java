import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class SaveOperation extends JFrame implements ActionListener {

	JButton save, exit;
	JTextField jtf;
	JLabel path = new JLabel("path: ");
	String file_path = "";
	MapEditor mp;
	String[] temp = new String[150];
	String str = "";

	public SaveOperation(MapEditor map) {

		this.mp = map;
		setLayout(null);

		save = new JButton("Save");
		exit = new JButton("Cancel");
		save.addActionListener(this);
		exit.addActionListener(this);
		save.setBounds(50, 170, 100, 60);
		exit.setBounds(350, 170, 100, 60);
		path.setBounds(40, 20, 50, 50);

		path.setFont(new Font(path.getFont().toString(), Font.BOLD, 15));

		jtf = new JTextField();
		jtf.setBounds(100, 20, 300, 50);
		jtf.setFont(new Font(jtf.getFont().toString(), Font.BOLD, 18));

		add(save);
		add(exit);
		add(jtf);
		add(path);
		setTitle("Save");
		setBounds(550, 300, 500, 300);
		setResizable(false);
		setVisible(true);

	}

	public static void main(String[] args) {

		// new SaveOperation();
	}

	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == exit) {
			setVisible(false);
		} else if (e.getSource() == save) {
			file_path = jtf.getText();
			save_file(file_path);
			setVisible(false);

		}

	}

	public void save_file(String path) {

		try {
			if (path.equalsIgnoreCase("")) {
				System.out.print("Error");
			} else {
				FileWriter fwr = new FileWriter(path, false);
				for (int i = 0; i < mp.imag.length; i++) {
					if (mp.imag[i].getIcon() == null) {
						temp[i] = "0" + ",";
					}
					for (int j = 0; j < mp.seas.length; j++) {
						if (mp.imag[i].getIcon() == mp.seas[j]) {
							temp[i] = String.valueOf(j + 1) + ",";
						} else if (mp.imag[i].getIcon() == mp.islands[j]) {
							temp[i] = String.valueOf(j + 29) + ",";
						}
					}

					str = str + temp[i];
				}
				fwr.write(str);
				fwr.close();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}

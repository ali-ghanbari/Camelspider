import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;

public class ClientStart extends JFrame implements ActionListener {

	Socket connection;
	DataOutputStream dos;
	JButton connect;
	JTextField jtf;

	public ClientStart() {

		connect = new JButton("Connect");
		connect.setBounds(125, 100, 100, 50);
		connect.addActionListener(this);
		jtf = new JTextField();
		jtf.setBounds(0, 0, 100, 40);

		add(connect);
		add(jtf);
		setLayout(null);
		setTitle("Client");
		setBounds(1300, 0, 300, 200);
		setResizable(false);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);

		try {
			connection = new Socket("127.0.0.1", 2020);
			dos = new DataOutputStream(connection.getOutputStream());
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public static void main(String[] args) {
		new ClientStart();

	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == connect) {

			try {
				dos.writeUTF(jtf.getText());
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}

	}

}

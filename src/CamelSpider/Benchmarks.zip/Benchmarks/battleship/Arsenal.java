import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Arsenal extends Ship {

	public Arsenal(int x_loc, int y_loc) {
		super();
		this.x_location = x_loc;
		this.y_locaton = y_loc;
		this.bfi = new BufferedImage(10, 10, BufferedImage.TYPE_INT_RGB);
		try {
			this.bfi = ImageIO.read(new File("new ship\\navy.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void paint(Graphics g) {
		super.paint(g);
		g.drawImage(this.bfi, this.x_location, this.y_locaton, null);
	}

	@Override
	public void Control() {
		// TODO Auto-generated method stu

	}

	@Override
	public void move(int x, int y) {
		// TODO Auto-generated method stub

	}

	@Override
	public void rotate(int dg) {
		// TODO Auto-generated method stub

	}

	@Override
	public void sale() {
		// TODO Auto-generated method stub

	}

	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	public void mouseDragged(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	public void run() {
		// TODO Auto-generated method stub

	}

	@Override
	public void RunMyThread(int x, int y) {
		// TODO Auto-generated method stub

	}
}

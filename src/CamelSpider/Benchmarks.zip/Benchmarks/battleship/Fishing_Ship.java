import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;

public class Fishing_Ship extends Ship {

	int x_temp, y_temp;
	Pos dest;

	public Fishing_Ship(int x_loc, int y_loc) {
		super();
		this.x_location = x_loc;
		this.y_locaton = y_loc;
		this.bfi = new BufferedImage(10, 10, BufferedImage.TYPE_INT_RGB);
		try {
			this.bfi = ImageIO.read(new File("new ship\\fishingship.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public int image_x() {
		return this.x_location;
	}

	public int image_y() {
		return this.y_locaton;
	}

	public int image_height() {
		return this.bfi.getHeight();
	}

	public int image_weight() {
		return this.bfi.getWidth();
	}

	@Override
	public void paint(Graphics g) {
		super.paint(g);
		g.drawImage(this.bfi, this.x_location, this.y_locaton, null);
	}

	@Override
	public void Control() {
		// TODO Auto-generated method stub

	}

	public void moveTo(int x, int y) {

		while (this.x_location != x || this.y_locaton != y) {
			try {
				Thread.sleep(50);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			if (this.x_location < x) {
				this.x_location++;
			} else if (this.x_location > x) {
				this.x_location--;
			}
			if (this.y_locaton < y) {
				this.y_locaton++;
			} else if (this.y_locaton > y) {
				this.y_locaton--;
			}
			this.repaint();
		}

		// StopMyThread();
	}

	@Override
	public void rotate(int dg) {
		// TODO Auto-generated method stub

	}

	@Override
	public void sale() {
		// TODO Auto-generated method stub

	}

	public void mouseClicked(MouseEvent e) {

	}

	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	public void mouseDragged(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	boolean isInLastIceland = false;
	ArrayList<Pos> circles = new ArrayList<Pos>();
	Pos NearestIceland = null;
	Pos myCircle = null;

	public void run() {
		updateDest();
		findNearCircles();
		int icelandIndex = findNearestIceland();
		if (icelandIndex == -1)
			FirstAlgoritm(dest);
		else {

			secondAlgoritm();
			circles.remove(icelandIndex);
			icelandIndex = findNearestIceland_1();
			while (icelandIndex > -1) {
				icelandIndex = findNearestIceland_2();
				thirdAlgoritm();

			}
			forthdAlgoritm();
		}
	}

	public void updateDest() {

	}

	public void findNearCircles() {
		Line line = new Line(shipVect.mid, dest);
		double baseAngle = Geometry.processAngleOfVector(shipVect.mid, dest);
		for (Pos c : WorldModel.Iceland) {
			if (Geometry.processDistanceFromLine(line, c) < 10
					&& Geometry.IsPointBetweenTwoPoints(c, shipVect.mid, dest,
							baseAngle)) {
				circles.add(c);
			}
		}

	}

	public int findNearestIceland() {
		Pos AnswerPos = null;

		Pos tempDest = new Pos(dest);
		ArrayList<Pos> tempCircles = circles;
		int previousIndex = -1;
		int index = Geometry.getFurthestPos(tempCircles, shipVect.mid,
				tempDest, AnswerPos);
		while (index > -1) {
			tempDest = Geometry.processPosOnCircle(new Line(shipVect.mid,
					tempDest), AnswerPos);
			tempCircles.remove(index);
			previousIndex = index;
			index = Geometry.getFurthestPos(tempCircles, shipVect.mid,
					tempDest, AnswerPos);
		}
		NearestIceland = AnswerPos;
		return previousIndex;
	}

	public int findNearestIceland_1() {
		return 0;
	}

	public int findNearestIceland_2() {
		return 0;
	}

	@Override
	public void RunMyThread(int x, int y) {
		this.x_temp = x;
		this.y_temp = y;
		(new MyThread(this)).start();
	}
}

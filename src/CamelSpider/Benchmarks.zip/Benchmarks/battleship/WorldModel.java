import java.util.ArrayList;

public class WorldModel {

	public static ArrayList<Pos> Iceland = new ArrayList<Pos>();
}

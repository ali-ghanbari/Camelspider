public class Circle {
	Pos center;
	double radius;

	public Circle(Pos center, double radius) {
		this.center = center;
		this.radius = radius;
	}
}
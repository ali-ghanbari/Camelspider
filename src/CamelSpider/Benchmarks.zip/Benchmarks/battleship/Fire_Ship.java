import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Fire_Ship extends Ship {

	int x_temp, y_temp;

	public Fire_Ship(int x_loc, int y_loc) {
		super();
		this.x_location = x_loc;
		this.y_locaton = y_loc;
		this.bfi = new BufferedImage(10, 10, BufferedImage.TYPE_INT_RGB);
		try {
			this.bfi = ImageIO.read(new File("new ship\\warship10.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public int image_x() {
		return this.x_location;
	}

	public int image_y() {
		return this.y_locaton;
	}

	public int image_height() {
		return this.bfi.getHeight();
	}

	public int image_weight() {
		return this.bfi.getWidth();
	}

	@Override
	public void Control() {
		// TODO Auto-generated method stub

	}

	@Override
	public void move(int x, int y) {
		// TODO Auto-generated method stub
		while (this.x_location != x || this.y_locaton != y) {
			try {
				Thread.sleep(50);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			if (this.x_location < x) {
				this.x_location++;
			} else if (this.x_location > x) {
				this.x_location--;
			}
			if (this.y_locaton < y) {
				this.y_locaton++;
			} else if (this.y_locaton > y) {
				this.y_locaton--;
			}
			this.repaint();
		}

	}

	@Override
	public void rotate(int dg) {
		// TODO Auto-generated method stub

	}

	@Override
	public void sale() {
		// TODO Auto-generated method stub

	}

	@Override
	public void paint(Graphics g) {
		super.paint(g);
		g.drawImage(this.bfi, this.x_location, this.y_locaton, null);
	}

	public void mouseClicked(MouseEvent e) {

	}

	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	public void mousePressed(MouseEvent e) {

	}

	public void mouseReleased(MouseEvent e) {
	}

	public void mouseDragged(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	public void run() {
		// TODO Auto-generated method stub
		move(x_temp, y_temp);
		System.out.println("fuck Thread");

	}

	@Override
	public void RunMyThread(int x, int y) {
		// TODO Auto-generated method stub
		this.x_temp = x;
		this.y_temp = y;
		(new MyThread(this)).start();

	}

}

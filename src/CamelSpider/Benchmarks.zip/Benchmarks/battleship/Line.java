public class Line {
	double a;
	double b;
	double c;

	public Line(double a, double b, double c) {
		this.a = a;
		this.b = b;
		this.c = c;
	}

	public Line(Pos p1, Pos p2) {
		a = (p1.y - p2.y) / (p1.x - p2.x);
		b = -1;
		c = p1.y - a * p1.x;
	}
}

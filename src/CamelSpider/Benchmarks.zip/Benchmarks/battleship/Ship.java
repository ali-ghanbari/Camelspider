import java.awt.Graphics;
import java.awt.image.BufferedImage;

import javax.swing.JPanel;
import javax.swing.event.MouseInputListener;

public abstract class Ship extends JPanel implements MouseInputListener,
		MyRunnable {

	public int damage;
	public BufferedImage bfi;
	public int x_location, y_locaton;
	public Vector shipVect;
	public boolean isBesideAnIceland = false;
	public Pos besideCircle = null;
	Thread Mythread;

	public Ship() {
		setBounds(0, 0, 3000, 2000);
		setOpaque(false);
		setLayout(null);
	}

	public void FirstAlgoritm(Pos dest) {
		double baseAngle = Geometry.processAngleOfVector(shipVect.mid, dest);
		int Clockwise = Geometry.processIfRotateIsClockwise(shipVect, dest);
		Pos O = Geometry.processRotateCenterForMyVect(shipVect, Clockwise);
		double ViewAng = Geometry
				.processHalfAngleofView(dest, new Circle(O, 3));
		Pos Momas = Geometry.RotatedPos(O,
				Geometry.processIntersectionPoint(new Circle(O, 3), dest),
				-Clockwise * ViewAng);
		double finalAngle = Geometry.processAngleOfVector(Momas, dest);
		double rotateang = Geometry.processAngleToTurn(shipVect.angle,
				finalAngle, Clockwise);
		rotate(O, rotateang);
		setLocation(Momas.x, Momas.y);
		// rotateAroudCenter(rotateang);
		goTowardDest(dest);
		setLocation(dest.x, dest.y);
	}

	/**
	 * this function is designed for this purpose : you are at the starting
	 * point and you wana to go near a circle, so: determine the exact point on
	 * the target circle and turn enough to make your direction along with the
	 * destination point and then go straight to the determined position.
	 */
	public void secondAlgoritm() {

	}

	/**
	 * this function is designed for this purpose : you are near a circle and
	 * wana go near another circle in the way, so: determine the exact points on
	 * the own and target circles and turn enough to make your direction along
	 * with the destination point on the target circle and then go straight to
	 * the determined position on the target circle.
	 */
	public void thirdAlgoritm() {

	}

	/**
	 * this function is designed for this purpose : you are near a circle and
	 * wana go final destination, so: determine the exact point on the own
	 * circle and turn enough to make your direction along with the destination
	 * point and then go straight to the target.
	 */
	public void forthdAlgoritm() {

	}

	public void rotate(Pos Center, double angle) {
		Pos rotatedPos;
		for (int i = 1; i < angle; i++) {
			rotatedPos = Geometry.RotatedPos(Center, shipVect.mid, i);
			rotateImage(i);
			this.setLocation(rotatedPos.x, rotatedPos.y);
			try {
				Thread.sleep(50);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	public void rotateImage(double angle) {

	}

	public void goTowardDest(Pos dest) {

	}

	// public abstract void moveTo(int x, int y);

	public abstract void rotate(int dg);

	public abstract void sale();

	public abstract void RunMyThread(int x, int y);

	public abstract void Control();

	@Override
	public void paint(Graphics g) {
	};
}

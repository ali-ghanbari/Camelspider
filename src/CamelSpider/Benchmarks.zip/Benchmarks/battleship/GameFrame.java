import java.awt.Color;
import java.awt.Container;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.StringTokenizer;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

public class GameFrame extends JFrame implements MouseListener, ActionListener,
		MouseMotionListener {

	JPanel[] panel = new JPanel[3];
	Container c;
	JButton left, right, up, down, exit;
	JTabbedPane tb1;
	JTabbedPane[] client_tab = new JTabbedPane[4];
	JPanel[][] my_pan = new JPanel[4][4];
	JPanel[] client_pan = new JPanel[4];
	int x, y, X, Y;
	JPanel temp_pan;
	Fire_Ship fs;
	Fishing_Ship fp;
	Arsenal ar;
	Engineer_Ship ens;
	int a = 0, b = 0;

	public GameFrame(String path) {

		Start(path);
		fs = new Fire_Ship(1000, 900);
		fp = new Fishing_Ship(1000, 700);
		ar = new Arsenal(1000, 1100);
		ens = new Engineer_Ship(1000, 1300);
		temp_pan.add(fs);
		temp_pan.add(fp);
		temp_pan.add(ar);
		temp_pan.add(ens);
		this.repaint();

	}

	public static void main(String[] args) {

		new GameFrame("fuckmap.txt");

	}

	public void Start(String path) {

		c = getContentPane();
		c.setLayout(null);

		tb1 = new JTabbedPane();
		tb1.setBounds(0, 0, 300, 900);

		for (int i = 0; i < panel.length; i++) {
			panel[i] = new JPanel();
		}
		for (int i = 0; i < client_pan.length; i++) {
			client_pan[i] = new JPanel();
			client_pan[i].setBounds(1300, 0, 300, 900);
			client_pan[i].setLayout(null);
			tb1.add("  Client  " + (i + 1), client_pan[i]);
		}
		for (int i = 0; i < client_tab.length; i++) {
			client_tab[i] = new JTabbedPane();
			client_tab[i].setBounds(0, 0, client_pan[i].getWidth(),
					client_pan[i].getHeight());
			client_pan[i].add(client_tab[i]);
			for (int j = 0; j < my_pan.length; j++) {
				my_pan[i][j] = new JPanel();
				my_pan[i][j].setBounds(0, 0, client_tab[i].getWidth(),
						client_tab[i].getHeight());
				client_tab[i].add("  ship " + (i + 1) + "," + (j + 1),
						my_pan[i][j]);
			}

		}

		panel[0].setLayout(null);
		panel[1].setLayout(null);
		panel[2].setLayout(null);

		temp_pan = new JPanel();
		temp_pan.setLayout(null);
		temp_pan.setBounds(0, 0, 3000, 2000);
		temp_pan.setOpaque(false);

		right = new JButton("Right");
		left = new JButton("Left");
		up = new JButton("Up");
		down = new JButton("Down");
		exit = new JButton("Exit");
		left.setBounds(255, 5, 100, 50);
		right.setBounds(360, 5, 100, 50);
		up.setBounds(475, 5, 100, 50);
		down.setBounds(580, 5, 100, 50);
		exit.setBounds(1140, 5, 100, 50);
		left.setForeground(Color.BLACK);
		right.setForeground(Color.BLACK);
		up.setForeground(Color.BLACK);
		down.setForeground(Color.BLACK);
		exit.setForeground(Color.BLACK);
		left.addMouseListener(this);
		right.addMouseListener(this);
		up.addMouseListener(this);
		down.addMouseListener(this);
		exit.addMouseListener(this);
		left.addActionListener(this);
		right.addActionListener(this);
		up.addActionListener(this);
		down.addActionListener(this);
		exit.addActionListener(this);

		panel[0].setBounds(1300, 0, 300, 900);
		panel[0].setBackground(Color.GREEN);

		panel[1].setBounds(0, 800, 1600, 100);
		panel[1].setBackground(Color.YELLOW);

		panel[2].setBounds(-800, -600, 3000, 2000);
		panel[2].setBackground(Color.PINK);
		panel[2].addMouseListener(this);
		panel[2].addMouseMotionListener(this);

		panel[0].add(tb1);
		panel[1].add(left);
		panel[1].add(right);
		panel[1].add(up);
		panel[1].add(down);
		panel[1].add(exit);
		panel[2].add(temp_pan, 0);
		panel[2].add(new Load_Operation(path), 1);
		panel[2].setOpaque(false);
		c.add(panel[1], 0);
		c.add(panel[0], 1);
		c.add(panel[2], 2);
		setTitle("Game Frame");
		setBounds(0, 0, 1600, 900);
		setUndecorated(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
	}

	public void mouseClicked(MouseEvent e) {

		if (e.getButton() == e.BUTTON3 && !e.isAltDown()) {
			int point_x = e.getX();
			int point_y = e.getY();

			if (point_x >= fp.image_x()
					&& point_x <= fp.image_weight() + fp.image_x()
					&& point_y >= fp.image_y()
					&& point_y <= fp.image_height() + fp.image_y()) {
				a = 1;
			}
		}

		else if (e.getButton() == e.BUTTON3 && e.isAltDown() && a == 1) {
			System.out.println("Hi");
			fp.RunMyThread(e.getX(), e.getY());
			a = 0;
		}
		if (e.getButton() == e.BUTTON3 && !e.isAltDown()) {
			int point_x = e.getX();
			int point_y = e.getY();

			if (point_x >= fs.image_x()
					&& point_x <= fs.image_weight() + fs.image_x()
					&& point_y >= fs.image_y()
					&& point_y <= fs.image_height() + fs.image_y()) {
				b = 1;
			}
		}

		else if (e.getButton() == e.BUTTON3 && e.isAltDown() && b == 1) {
			System.out.println("Hi");
			fs.RunMyThread(e.getX(), e.getY());
			b = 0;
		}

	}

	public void mouseEntered(MouseEvent e) {

		if (e.getSource() == left) {
			left.setForeground(Color.RED);
		} else if (e.getSource() == right) {
			right.setForeground(Color.RED);
		} else if (e.getSource() == up) {
			up.setForeground(Color.RED);
		} else if (e.getSource() == down) {
			down.setForeground(Color.RED);
		} else if (e.getSource() == exit) {
			exit.setForeground(Color.RED);
		}

	}

	public void mouseExited(MouseEvent e) {

		if (e.getSource() == left) {
			left.setForeground(Color.BLACK);
		} else if (e.getSource() == right) {
			right.setForeground(Color.BLACK);
		} else if (e.getSource() == up) {
			up.setForeground(Color.black);
		} else if (e.getSource() == down) {
			down.setForeground(Color.BLACK);
		} else if (e.getSource() == exit) {
			exit.setForeground(Color.BLACK);
		}

	}

	public void mousePressed(MouseEvent e) {

		if (e.getSource() == panel[2]) {
			x = e.getX();
			y = e.getY();
		}
	}

	public void mouseReleased(MouseEvent e) {

	}

	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == left) {
			if (panel[2].getX() > -1700)
				panel[2].setLocation(panel[2].getX() - 100, panel[2].getY());
		} else if (e.getSource() == right) {
			if (panel[2].getX() < 0)
				panel[2].setLocation(panel[2].getX() + 100, panel[2].getY());
		} else if (e.getSource() == up) {
			if (panel[2].getY() > -1200)
				panel[2].setLocation(panel[2].getX(), panel[2].getY() - 100);
		} else if (e.getSource() == down) {
			if (panel[2].getY() < 0)
				panel[2].setLocation(panel[2].getX(), panel[2].getY() + 100);
		} else if (e.getSource() == exit) {
			System.exit(0);
		}

	}

	public void mouseDragged(MouseEvent e) {

		if (e.getSource() == panel[2]) {
			X = e.getX() - x;
			Y = e.getY() - y;
			if (panel[2].getX() + X > -1700 && panel[2].getX() + X < 0
					&& panel[2].getY() + Y > -1200 && panel[2].getY() + Y < 0) {
				panel[2].setLocation(panel[2].getX() + X, panel[2].getY() + Y);
			}
		}
	}

	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub

	}

}

import java.awt.Color;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTabbedPane;
import javax.swing.event.MouseInputListener;
import javax.swing.plaf.basic.BasicBorders.RadioButtonBorder;

public class MapEditor extends JFrame implements FocusListener, ActionListener,
		ItemListener, MouseListener, MouseMotionListener {

	JPanel[] panel = new JPanel[3];
	Container c;
	JRadioButton[] rb = new JRadioButton[56];
	JLabel[] lab = new JLabel[56];
	JLabel[] imag = new JLabel[150];
	JTabbedPane tab = new JTabbedPane();
	JPanel[] tab_panel = new JPanel[4];
	ImageIcon[] seas = new ImageIcon[28];
	ImageIcon[] islands = new ImageIcon[28];
	ImageIcon[] mini_icon = new ImageIcon[56];

	ImageIcon current_icon = null;
	ButtonGroup btg;
	JButton left, right, up, down, save, exit;
	int x, y, X, Y;

	public MapEditor() {

		seas[0] = new ImageIcon("seas\\sea2.png");
		seas[1] = new ImageIcon("seas\\sea21.png");
		seas[2] = new ImageIcon("seas\\sea22.png");
		seas[3] = new ImageIcon("seas\\sea23.png");
		seas[4] = new ImageIcon("seas\\sea24.png");
		seas[5] = new ImageIcon("seas\\sea25.png");
		seas[6] = new ImageIcon("seas\\sea26.png");
		seas[7] = new ImageIcon("seas\\sea27.png");
		seas[8] = new ImageIcon("seas\\sea28.png");
		seas[9] = new ImageIcon("seas\\sea290.png");
		seas[10] = new ImageIcon("seas\\sea291.png");
		seas[11] = new ImageIcon("seas\\sea292.png");
		seas[12] = new ImageIcon("seas\\sea293.png");
		seas[13] = new ImageIcon("seas\\sea30.png");
		seas[14] = new ImageIcon("seas\\sea1.png");
		seas[15] = new ImageIcon("seas\\sea11.png");
		seas[16] = new ImageIcon("seas\\sea12.png");
		seas[17] = new ImageIcon("seas\\sea13.png");
		seas[18] = new ImageIcon("seas\\sea14.png");
		seas[19] = new ImageIcon("seas\\sea15.png");
		seas[20] = new ImageIcon("seas\\sea16.png");
		seas[21] = new ImageIcon("seas\\sea17.png");
		seas[22] = new ImageIcon("seas\\sea18.png");
		seas[23] = new ImageIcon("seas\\sea190.png");
		seas[24] = new ImageIcon("seas\\sea191.png");
		seas[25] = new ImageIcon("seas\\sea192.png");
		seas[26] = new ImageIcon("seas\\sea193.png");
		seas[27] = new ImageIcon("seas\\sea20.png");

		islands[0] = new ImageIcon("islands\\island200.png");
		islands[1] = new ImageIcon("islands\\island201.png");
		islands[2] = new ImageIcon("islands\\island202.png");
		islands[3] = new ImageIcon("islands\\island203.png");
		islands[4] = new ImageIcon("islands\\island204.png");
		islands[5] = new ImageIcon("islands\\island205.png");
		islands[6] = new ImageIcon("islands\\island206.png");
		islands[7] = new ImageIcon("islands\\island207.png");
		islands[8] = new ImageIcon("islands\\island208.png");
		islands[9] = new ImageIcon("islands\\island290.png");
		islands[10] = new ImageIcon("islands\\island291.png");
		islands[11] = new ImageIcon("islands\\island292.png");
		islands[12] = new ImageIcon("islands\\island293.png");
		islands[13] = new ImageIcon("islands\\island294.png");
		islands[14] = new ImageIcon("islands\\island100.png");
		islands[15] = new ImageIcon("islands\\island101.png");
		islands[16] = new ImageIcon("islands\\island102.png");
		islands[17] = new ImageIcon("islands\\island103.png");
		islands[18] = new ImageIcon("islands\\island104.png");
		islands[19] = new ImageIcon("islands\\island105.png");
		islands[20] = new ImageIcon("islands\\island106.png");
		islands[21] = new ImageIcon("islands\\island107.png");
		islands[22] = new ImageIcon("islands\\island108.png");
		islands[23] = new ImageIcon("islands\\island190.png");
		islands[24] = new ImageIcon("islands\\island191.png");
		islands[25] = new ImageIcon("islands\\island192.png");
		islands[26] = new ImageIcon("islands\\island193.png");
		islands[27] = new ImageIcon("islands\\island194.png");

		mini_icon[0] = new ImageIcon("mini icon\\sea2.png");
		mini_icon[1] = new ImageIcon("mini icon\\sea21.png");
		mini_icon[2] = new ImageIcon("mini icon\\sea22.png");
		mini_icon[3] = new ImageIcon("mini icon\\sea23.png");
		mini_icon[4] = new ImageIcon("mini icon\\sea24.png");
		mini_icon[5] = new ImageIcon("mini icon\\sea25.png");
		mini_icon[6] = new ImageIcon("mini icon\\sea26.png");
		mini_icon[7] = new ImageIcon("mini icon\\sea27.png");
		mini_icon[8] = new ImageIcon("mini icon\\sea28.png");
		mini_icon[9] = new ImageIcon("mini icon\\sea290.png");
		mini_icon[10] = new ImageIcon("mini icon\\sea291.png");
		mini_icon[11] = new ImageIcon("mini icon\\sea292.png");
		mini_icon[12] = new ImageIcon("mini icon\\sea293.png");
		mini_icon[13] = new ImageIcon("mini icon\\sea30.png");
		mini_icon[14] = new ImageIcon("mini icon\\sea1.png");
		mini_icon[15] = new ImageIcon("mini icon\\sea11.png");
		mini_icon[16] = new ImageIcon("mini icon\\sea12.png");
		mini_icon[17] = new ImageIcon("mini icon\\sea13.png");
		mini_icon[18] = new ImageIcon("mini icon\\sea14.png");
		mini_icon[19] = new ImageIcon("mini icon\\sea15.png");
		mini_icon[20] = new ImageIcon("mini icon\\sea16.png");
		mini_icon[21] = new ImageIcon("mini icon\\sea17.png");
		mini_icon[22] = new ImageIcon("mini icon\\sea18.png");
		mini_icon[23] = new ImageIcon("mini icon\\sea190.png");
		mini_icon[24] = new ImageIcon("mini icon\\sea191.png");
		mini_icon[25] = new ImageIcon("mini icon\\sea192.png");
		mini_icon[26] = new ImageIcon("mini icon\\sea193.png");
		mini_icon[27] = new ImageIcon("mini icon\\sea20.png");
		mini_icon[28] = new ImageIcon("mini icon\\island200.png");
		mini_icon[29] = new ImageIcon("mini icon\\island201.png");
		mini_icon[30] = new ImageIcon("mini icon\\island202.png");
		mini_icon[31] = new ImageIcon("mini icon\\island203.png");
		mini_icon[32] = new ImageIcon("mini icon\\island204.png");
		mini_icon[33] = new ImageIcon("mini icon\\island205.png");
		mini_icon[34] = new ImageIcon("mini icon\\island206.png");
		mini_icon[35] = new ImageIcon("mini icon\\island207.png");
		mini_icon[36] = new ImageIcon("mini icon\\island208.png");
		mini_icon[37] = new ImageIcon("mini icon\\island290.png");
		mini_icon[38] = new ImageIcon("mini icon\\island291.png");
		mini_icon[39] = new ImageIcon("mini icon\\island292.png");
		mini_icon[40] = new ImageIcon("mini icon\\island293.png");
		mini_icon[41] = new ImageIcon("mini icon\\island294.png");
		mini_icon[42] = new ImageIcon("mini icon\\island100.png");
		mini_icon[43] = new ImageIcon("mini icon\\island101.png");
		mini_icon[44] = new ImageIcon("mini icon\\island102.png");
		mini_icon[45] = new ImageIcon("mini icon\\island103.png");
		mini_icon[46] = new ImageIcon("mini icon\\island104.png");
		mini_icon[47] = new ImageIcon("mini icon\\island105.png");
		mini_icon[48] = new ImageIcon("mini icon\\island106.png");
		mini_icon[49] = new ImageIcon("mini icon\\island107.png");
		mini_icon[50] = new ImageIcon("mini icon\\island108.png");
		mini_icon[51] = new ImageIcon("mini icon\\island190.png");
		mini_icon[52] = new ImageIcon("mini icon\\island191.png");
		mini_icon[53] = new ImageIcon("mini icon\\island192.png");
		mini_icon[54] = new ImageIcon("mini icon\\island193.png");
		mini_icon[55] = new ImageIcon("mini icon\\island194.png");

		c = getContentPane();
		c.setLayout(null);

		for (int i = 0; i < panel.length; i++) {
			panel[i] = new JPanel();
		}

		panel[0].setLayout(null);
		panel[1].setLayout(null);
		panel[2].setLayout(new GridLayout(10, 15));

		btg = new ButtonGroup();

		for (int i = 0; i < tab_panel.length; i++) {
			tab_panel[i] = new JPanel();
			tab_panel[i].setBounds(0, 0, 300, 900);
			tab_panel[i].setLayout(null);
		}

		tab.setBounds(0, 0, 300, 900);
		tab.add("   Sea 1 ", tab_panel[0]);
		tab.add("   Sea 2 ", tab_panel[1]);
		tab.add("   Island 1 ", tab_panel[2]);
		tab.add("   Island 2 ", tab_panel[3]);

		panel[0].add(tab);

		for (int i = 0; i < 14; i++) {

			rb[i] = new JRadioButton();
			rb[i].setForeground(Color.BLACK);
			tab_panel[0].add(rb[i]);
			lab[i] = new JLabel(mini_icon[i]);
			lab[i].setBounds(40, i * 60 + 20, 50, 50);
			tab_panel[0].add(lab[i]);
			btg.add(rb[i]);
			rb[i].setBounds(160, i * 60 + 15, 100, 60);
			rb[i].setText("sea " + (i + 1));
			rb[i].addMouseListener(this);
			rb[i].addItemListener(this);

		}

		for (int i = 14; i < 28; i++) {

			rb[i] = new JRadioButton();
			rb[i].setForeground(Color.BLACK);
			tab_panel[1].add(rb[i]);
			lab[i] = new JLabel(mini_icon[i]);
			lab[i].setBounds(40, (i - 14) * 60 + 20, 50, 50);
			tab_panel[1].add(lab[i]);
			btg.add(rb[i]);
			rb[i].setBounds(160, (i - 14) * 60 + 15, 100, 60);
			rb[i].setText("sea " + (i + 1));
			rb[i].addMouseListener(this);
			rb[i].addItemListener(this);

		}

		for (int i = 28; i < 42; i++) {
			rb[i] = new JRadioButton();
			rb[i].setForeground(Color.BLACK);
			tab_panel[2].add(rb[i]);
			lab[i] = new JLabel(mini_icon[i]);
			lab[i].setBounds(40, (i - 28) * 60 + 20, 50, 50);
			tab_panel[2].add(lab[i]);
			btg.add(rb[i]);
			rb[i].setBounds(160, (i - 28) * 60 + 15, 100, 60);
			rb[i].setText("Island " + (i - 27));
			rb[i].addMouseListener(this);
			rb[i].addItemListener(this);
		}

		for (int i = 42; i < 56; i++) {
			rb[i] = new JRadioButton();
			rb[i].setForeground(Color.BLACK);
			tab_panel[3].add(rb[i]);
			lab[i] = new JLabel(mini_icon[i]);
			lab[i].setBounds(40, (i - 42) * 60 + 20, 50, 50);
			tab_panel[3].add(lab[i]);
			btg.add(rb[i]);
			rb[i].setBounds(160, (i - 42) * 60 + 15, 100, 60);
			rb[i].setText("Island " + (i - 27));
			rb[i].addMouseListener(this);
			rb[i].addItemListener(this);
		}

		for (int i = 0; i < imag.length; i++) {
			imag[i] = new JLabel();
			panel[2].add(imag[i]);
			imag[i].addMouseListener(this);
		}

		right = new JButton("Right");
		left = new JButton("Left");
		up = new JButton("Up");
		down = new JButton("Down");
		save = new JButton("Save");
		exit = new JButton("Exit");
		left.setBounds(255, 5, 100, 50);
		right.setBounds(360, 5, 100, 50);
		up.setBounds(475, 5, 100, 50);
		down.setBounds(580, 5, 100, 50);
		save.setBounds(1030, 5, 100, 50);
		exit.setBounds(1140, 5, 100, 50);
		left.setForeground(Color.BLACK);
		right.setForeground(Color.BLACK);
		up.setForeground(Color.BLACK);
		down.setForeground(Color.BLACK);
		save.setForeground(Color.BLACK);
		exit.setForeground(Color.BLACK);
		left.addMouseListener(this);
		right.addMouseListener(this);
		up.addMouseListener(this);
		down.addMouseListener(this);
		save.addMouseListener(this);
		exit.addMouseListener(this);
		left.addActionListener(this);
		right.addActionListener(this);
		up.addActionListener(this);
		down.addActionListener(this);
		save.addActionListener(this);
		exit.addActionListener(this);

		panel[0].setBounds(1300, 0, 300, 900);

		panel[1].setBounds(0, 800, 1300, 100);
		panel[1].setBackground(Color.YELLOW);

		panel[2].setBounds(-800, -600, 3000, 2000);
		panel[2].setBackground(Color.PINK);
		panel[2].addMouseMotionListener(this);

		panel[1].add(left);
		panel[1].add(right);
		panel[1].add(up);
		panel[1].add(down);
		panel[1].add(save);
		panel[1].add(exit);
		c.add(panel[0]);
		c.add(panel[1]);
		c.add(panel[2]);
		setTitle("Map Editor");
		setBounds(0, 0, 1600, 900);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setUndecorated(true);
		setVisible(true);

	}

	public static void main(String[] args) {

		new MapEditor();

	}

	public void focusGained(FocusEvent e) {

	}

	public void focusLost(FocusEvent e) {

	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == left) {
			if (panel[2].getX() > -1700)
				panel[2].setLocation(panel[2].getX() - 100, panel[2].getY());
		} else if (e.getSource() == right) {
			if (panel[2].getX() < 0)
				panel[2].setLocation(panel[2].getX() + 100, panel[2].getY());
		} else if (e.getSource() == up) {
			if (panel[2].getY() > -1200)
				panel[2].setLocation(panel[2].getX(), panel[2].getY() - 100);
		} else if (e.getSource() == down) {
			if (panel[2].getY() < 0)
				panel[2].setLocation(panel[2].getX(), panel[2].getY() + 100);
		} else if (e.getSource() == exit) {
			System.exit(0);
		} else if (e.getSource() == save) {

			new SaveOperation(this);

		}

	}

	public void itemStateChanged(ItemEvent e) {

		for (int i = 0; i < 28; i++) {

			if (e.getSource() == rb[i]) {
				current_icon = seas[i];
			} else if (e.getSource() == rb[i + 28]) {
				current_icon = islands[i];
			}

		}

	}

	public void mouseClicked(MouseEvent e) {

		for (int i = 0; i < imag.length; i++) {
			if (e.getSource() == imag[i] && !e.isControlDown()) {
				imag[i].setIcon(current_icon);
			} else if (e.getSource() == imag[i] && e.isControlDown()) {
				imag[i].setIcon(null);
			}
			this.repaint();
		}

	}

	public void mouseEntered(MouseEvent e) {
		for (int i = 0; i < rb.length; i++) {
			if (e.getSource() == rb[i]) {
				rb[i].setForeground(Color.RED);
			}
		}
		if (e.getSource() == left) {
			left.setForeground(Color.RED);
		} else if (e.getSource() == right) {
			right.setForeground(Color.RED);
		} else if (e.getSource() == up) {
			up.setForeground(Color.RED);
		} else if (e.getSource() == down) {
			down.setForeground(Color.RED);
		} else if (e.getSource() == save) {
			save.setForeground(Color.RED);
		} else if (e.getSource() == exit) {
			exit.setForeground(Color.RED);
		}

	}

	public void mouseExited(MouseEvent e) {

		for (int i = 0; i < rb.length; i++) {
			if (e.getSource() == rb[i]) {
				rb[i].setForeground(Color.BLACK);
			}
		}
		if (e.getSource() == left) {
			left.setForeground(Color.BLACK);
		} else if (e.getSource() == right) {
			right.setForeground(Color.BLACK);
		} else if (e.getSource() == up) {
			up.setForeground(Color.black);
		} else if (e.getSource() == down) {
			down.setForeground(Color.BLACK);
		} else if (e.getSource() == save) {
			save.setForeground(Color.BLACK);
		} else if (e.getSource() == exit) {
			exit.setForeground(Color.BLACK);
		}
	}

	public void mousePressed(MouseEvent e) {

	}

	public void mouseReleased(MouseEvent e) {

	}

	public void mouseDragged(MouseEvent e) {

	}

	public void mouseMoved(MouseEvent e) {

	}

}
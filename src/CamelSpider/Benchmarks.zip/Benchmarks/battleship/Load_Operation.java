import java.awt.GridLayout;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.StringTokenizer;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Load_Operation extends JPanel {

	ImageIcon[] seas = new ImageIcon[28];
	ImageIcon[] islands = new ImageIcon[28];
	FileReader fr;
	BufferedReader bfr;
	String load = "";
	StringTokenizer toki;
	JLabel[] imag = new JLabel[150];

	public Load_Operation(String path) {

		setLayout(new GridLayout(10, 15));
		setBounds(0, 0, 3000, 2000);

		seas[0] = new ImageIcon("seas\\sea2.png");
		seas[1] = new ImageIcon("seas\\sea21.png");
		seas[2] = new ImageIcon("seas\\sea22.png");
		seas[3] = new ImageIcon("seas\\sea23.png");
		seas[4] = new ImageIcon("seas\\sea24.png");
		seas[5] = new ImageIcon("seas\\sea25.png");
		seas[6] = new ImageIcon("seas\\sea26.png");
		seas[7] = new ImageIcon("seas\\sea27.png");
		seas[8] = new ImageIcon("seas\\sea28.png");
		seas[9] = new ImageIcon("seas\\sea290.png");
		seas[10] = new ImageIcon("seas\\sea291.png");
		seas[11] = new ImageIcon("seas\\sea292.png");
		seas[12] = new ImageIcon("seas\\sea293.png");
		seas[13] = new ImageIcon("seas\\sea30.png");
		seas[14] = new ImageIcon("seas\\sea1.png");
		seas[15] = new ImageIcon("seas\\sea11.png");
		seas[16] = new ImageIcon("seas\\sea12.png");
		seas[17] = new ImageIcon("seas\\sea13.png");
		seas[18] = new ImageIcon("seas\\sea14.png");
		seas[19] = new ImageIcon("seas\\sea15.png");
		seas[20] = new ImageIcon("seas\\sea16.png");
		seas[21] = new ImageIcon("seas\\sea17.png");
		seas[22] = new ImageIcon("seas\\sea18.png");
		seas[23] = new ImageIcon("seas\\sea190.png");
		seas[24] = new ImageIcon("seas\\sea191.png");
		seas[25] = new ImageIcon("seas\\sea192.png");
		seas[26] = new ImageIcon("seas\\sea193.png");
		seas[27] = new ImageIcon("seas\\sea20.png");

		islands[0] = new ImageIcon("islands\\island200.png");
		islands[1] = new ImageIcon("islands\\island201.png");
		islands[2] = new ImageIcon("islands\\island202.png");
		islands[3] = new ImageIcon("islands\\island203.png");
		islands[4] = new ImageIcon("islands\\island204.png");
		islands[5] = new ImageIcon("islands\\island205.png");
		islands[6] = new ImageIcon("islands\\island206.png");
		islands[7] = new ImageIcon("islands\\island207.png");
		islands[8] = new ImageIcon("islands\\island208.png");
		islands[9] = new ImageIcon("islands\\island290.png");
		islands[10] = new ImageIcon("islands\\island291.png");
		islands[11] = new ImageIcon("islands\\island292.png");
		islands[12] = new ImageIcon("islands\\island293.png");
		islands[13] = new ImageIcon("islands\\island294.png");
		islands[14] = new ImageIcon("islands\\island100.png");
		islands[15] = new ImageIcon("islands\\island101.png");
		islands[16] = new ImageIcon("islands\\island102.png");
		islands[17] = new ImageIcon("islands\\island103.png");
		islands[18] = new ImageIcon("islands\\island104.png");
		islands[19] = new ImageIcon("islands\\island105.png");
		islands[20] = new ImageIcon("islands\\island106.png");
		islands[21] = new ImageIcon("islands\\island107.png");
		islands[22] = new ImageIcon("islands\\island108.png");
		islands[23] = new ImageIcon("islands\\island190.png");
		islands[24] = new ImageIcon("islands\\island191.png");
		islands[25] = new ImageIcon("islands\\island192.png");
		islands[26] = new ImageIcon("islands\\island193.png");
		islands[27] = new ImageIcon("islands\\island194.png");

		try {
			fr = new FileReader(path);
			bfr = new BufferedReader(fr);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

		for (int i = 0; i < imag.length; i++) {
			imag[i] = new JLabel();
			add(imag[i]);
		}
		Set_Map();

	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {

	}

	public void Set_Map() {

		String temp;
		String[] siki = new String[200];
		int u = 0;

		try {

			while ((temp = bfr.readLine()) != null) {
				load = temp + load;
			}

			toki = new StringTokenizer(load, ",");

			while (toki.hasMoreTokens()) {
				siki[u] = toki.nextToken();
				u++;
			}

			for (int j = 0; j < u; j++) {
				for (int i = 0; i < 28; i++) {
					if (siki[j].equalsIgnoreCase(String.valueOf(i + 1))) {
						imag[j].setIcon(seas[i]);
					} else if (siki[j].equalsIgnoreCase(String.valueOf(i + 29))) {
						imag[j].setIcon(islands[i]);
					}
				}

				if (siki[j].equalsIgnoreCase("0")) {
					imag[j].setIcon(null);
				}
			}

		} catch (IOException e1) {

			e1.printStackTrace();
		}
	}

}

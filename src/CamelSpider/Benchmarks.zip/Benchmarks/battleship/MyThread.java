public class MyThread extends Thread {
	private MyRunnable r;

	public MyThread() {
		r = null;
	}

	public MyThread(MyRunnable r) {
		this.r = r;
	}

	public void run () {
		if(r != null)		
			r.run();
	}
}

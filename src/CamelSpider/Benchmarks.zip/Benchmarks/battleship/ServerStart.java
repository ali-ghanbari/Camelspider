import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.text.StyledEditorKit.ItalicAction;

public class ServerStart extends JFrame implements FocusListener,
		MouseListener, ActionListener, ItemListener {

	static int PN;
	ServerSocket server;
	Socket[] connection = new Socket[3];
	Container c;
	JPanel[] panel = new JPanel[2];
	JButton LM, NM, Play, Exit;
	static JLabel[] L = new JLabel[3];
	JLabel Players = new JLabel("Number of Players: ");
	JLabel CPU = new JLabel("Strategy of CPU: ");
	JComboBox jcb1, jcb2;
	boolean play_status = false;
	String nick;
	String[] com1 = { "Two", "Three", "Four" };
	String[] com2 = { "One", "Two" };
	ImageIcon pic = new ImageIcon("first-pic.jpg");
	JLabel picture = new JLabel(pic);
	JLabel Directory = new JLabel("");

	public ServerStart() {

		c = getContentPane();
		c.setLayout(new GridLayout(2, 0));

		for (int i = 0; i < panel.length; i++) {
			panel[i] = new JPanel();
		}
		for (int i = 0; i < L.length; i++) {
			L[i] = new JLabel("");
		}

		jcb1 = new JComboBox(com1);
		jcb1.setBounds(150, 5, 60, 30);
		jcb1.setForeground(Color.BLACK);
		jcb1.addFocusListener(this);
		jcb1.addItemListener(this);
		jcb2 = new JComboBox(com2);
		jcb2.setBounds(150, 80, 50, 30);
		jcb2.setForeground(Color.BLACK);
		jcb2.addFocusListener(this);
		jcb2.addItemListener(this);

		LM = new JButton("Load Map");
		NM = new JButton("New Map");
		Play = new JButton("Play Game");
		Exit = new JButton("Exit");
		LM.setBounds(200, 150, 150, 50);
		NM.setBounds(430, 150, 150, 50);
		Play.setBounds(20, 220, 150, 50);
		Exit.setBounds(620, 220, 150, 50);
		Play.setEnabled(play_status);
		LM.setForeground(Color.BLACK);
		NM.setForeground(Color.BLACK);
		Play.setForeground(Color.BLACK);
		Exit.setForeground(Color.BLACK);
		LM.addFocusListener(this);
		NM.addFocusListener(this);
		Play.addFocusListener(this);
		Exit.addFocusListener(this);
		LM.addMouseListener(this);
		NM.addMouseListener(this);
		Play.addMouseListener(this);
		Exit.addMouseListener(this);
		LM.addActionListener(this);
		NM.addActionListener(this);
		Play.addActionListener(this);
		Exit.addActionListener(this);

		Directory.setBounds(230, 220, 350, 50);
		Directory.setForeground(Color.BLACK);
		Directory.setFont(new Font(Directory.getFont().toString(), 0, 18));
		// Directory.setEnabled(false);

		L[0].setBounds(400, 15, 400, 20);
		L[0].setFont(new Font("Elephant", 2, 20));
		L[0].setForeground(Color.red);
		L[1].setBounds(400, 55, 400, 20);
		L[1].setFont(new Font("Elephant", 2, 20));
		L[1].setForeground(Color.GREEN);
		L[2].setBounds(400, 95, 400, 20);
		L[2].setFont(new Font("Elephant", 2, 20));
		L[2].setForeground(Color.blue);

		Players.setBounds(5, 15, 180, 15);
		Players.setFont(new Font("Minion Pro SmBd", 1, 15));
		Players.setForeground(Color.BLACK);

		CPU.setBounds(5, 85, 130, 20);
		CPU.setFont(new Font("Minion Pro SmBd", 1, 15));
		CPU.setForeground(Color.BLACK);

		// picture.setBounds(0, 0, 400, 300);

		panel[0].setBackground(Color.YELLOW);
		panel[0].setLayout(new GridLayout(1, 0));
		panel[1].setBackground(Color.WHITE);

		panel[1].setLayout(null);
		panel[1].add(LM);
		panel[1].add(NM);
		panel[1].add(Play);
		panel[1].add(Exit);
		panel[1].add(L[0]);
		panel[1].add(L[1]);
		panel[1].add(L[2]);
		panel[1].add(Players);
		panel[1].add(CPU);
		panel[1].add(jcb1);
		panel[1].add(jcb2);
		panel[1].add(Directory);
		panel[0].add(picture);
		c.add(panel[0]);
		c.add(panel[1]);
		setTitle("Server");
		setBounds(400, 150, 800, 600);
		// setResizable(false);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setUndecorated(true);
		setVisible(true);

		try {
			server = new ServerSocket(2020);
			SocketDemo[] sd = new SocketDemo[3];
			while (true) {
				for (int i = 0; i < 3; i++) {
					connection[i] = server.accept();
					System.out.println("accepted");
					sd[i] = new SocketDemo(connection[i], i);
					(new Thread(sd[i])).start();
				}
			}

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public static void main(String[] args) {
		new ServerStart();

	}

	public void focusGained(FocusEvent e) {
		if (e.getSource() == jcb1) {
			Players.setForeground(Color.RED);
		}
		if (e.getSource() == jcb2) {
			CPU.setForeground(Color.RED);
		}
		if (e.getSource() == LM) {
			LM.setForeground(Color.RED);
		}
		if (e.getSource() == NM) {
			NM.setForeground(Color.RED);
		}
		if (e.getSource() == Play) {
			Play.setForeground(Color.RED);
		}
		if (e.getSource() == Exit) {
			Exit.setForeground(Color.RED);
		}

	}

	public void focusLost(FocusEvent e) {
		if (e.getSource() == jcb1) {
			Players.setForeground(Color.BLACK);
		}
		if (e.getSource() == jcb2) {
			CPU.setForeground(Color.BLACK);
		}
		if (e.getSource() == LM) {
			LM.setForeground(Color.BLACK);
		}
		if (e.getSource() == NM) {
			NM.setForeground(Color.BLACK);
		}
		if (e.getSource() == Play) {
			Play.setForeground(Color.BLACK);
		}
		if (e.getSource() == Exit) {
			Exit.setForeground(Color.BLACK);
		}
	}

	public void mouseClicked(MouseEvent e) {

	}

	public void mouseEntered(MouseEvent e) {
		if (e.getSource() == LM) {
			LM.setForeground(Color.RED);
		}
		if (e.getSource() == NM) {
			NM.setForeground(Color.RED);
		}
		if (e.getSource() == Play) {
			Play.setForeground(Color.RED);
		}
		if (e.getSource() == Exit) {
			Exit.setForeground(Color.RED);
		}

	}

	public void mouseExited(MouseEvent e) {
		if (e.getSource() == LM) {
			LM.setForeground(Color.BLACK);
		}
		if (e.getSource() == NM) {
			NM.setForeground(Color.BLACK);
		}
		if (e.getSource() == Play) {
			Play.setForeground(Color.BLACK);
		}
		if (e.getSource() == Exit) {
			Exit.setForeground(Color.BLACK);
		}

	}

	public void mousePressed(MouseEvent e) {

	}

	public void mouseReleased(MouseEvent e) {

	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == Exit) {
			System.exit(0);
		}
		if (e.getSource() == NM) {
			new MapEditor();
		}
		if (e.getSource() == LM) {
			JFileChooser fileChooser = new JFileChooser();
			fileChooser.setLocation(500, 500);
			int result = fileChooser.showDialog(this, "Open");
			if (result == JFileChooser.APPROVE_OPTION) {
				File file = fileChooser.getSelectedFile();
				String f = new String(file.toString());
				if (f.charAt(f.length() - 1) == 't'
						&& f.charAt(f.length() - 2) == 'x'
						&& f.charAt(f.length() - 3) == 't') {
					Directory.setText(f);
					new GameFrame(f);
					// Path = new String(f);
				} else {
					Directory.setText("Error: You should load text files");
				}
			}
		}

	}

	public void itemStateChanged(ItemEvent e) {
		if (e.getSource() == jcb1) {
			if (jcb1.getSelectedIndex() == 0) {
				PN = 1;
			}
			if (jcb1.getSelectedIndex() == 1) {
				PN = 2;
			}
			if (jcb1.getSelectedIndex() == 2) {
				PN = 3;
			}
		}

	}

}

class SocketDemo extends MyThread {
	DataInputStream dis;
	DataOutputStream dos;
	Socket connection;
	int po;

	public SocketDemo(Socket connection, int po) {
		this.connection = connection;
		this.po = po;
		try {
			dis = new DataInputStream(this.connection.getInputStream());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void run() {

		while (true) {
			try {
				if (dis.available() > 0) {
					ServerStart.L[po].setText(dis.readUTF()
							+ "  has been connected");
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

}

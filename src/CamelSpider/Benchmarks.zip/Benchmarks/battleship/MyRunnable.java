public interface MyRunnable {
	abstract public void run();
}

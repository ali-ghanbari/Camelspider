import java.lang.Math;
import java.util.ArrayList;

public class Geometry {
	public static final int ROTATE_RADIUS = 5;
	public static final int ICELAND_RADIUS = 5;

	public static double processDistanceOfPoses(Pos pos1, Pos pos2) {
		int x1 = pos1.x;
		int y1 = pos1.y;
		int x2 = pos2.x;
		int y2 = pos2.y;
		return Math.sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));
	}

	public static double processHalfAngleofView(Pos pos, Circle c) {
		double d = processDistanceOfPoses(pos, c.center);

		return Math.asin(c.radius / d);
	}

	public static Pos RotatedPos(Pos centerPos, Pos pos, double angle) {
		int x = pos.x - centerPos.x;
		int y = pos.y - centerPos.y;
		int rotX = (int) (Math.cos(angle) * x - Math.sin(angle) * y);
		int rotY = (int) (Math.sin(angle) * x + Math.cos(angle) * y);
		return new Pos(rotX + centerPos.x, rotY + centerPos.y);
	}

	public static double processAngleOfVector(Pos start, Pos end) {
		if (end.y < start.y)
			return 180.0 + Math.atan((end.y - start.y) / (end.x - start.x));
		else if (end.y > start.y)
			return Math.atan((end.y - start.y) / (end.x - start.x));
		else if (end.x > start.x)
			return 0.0;
		else
			return 180.0;
	}

	public static int processIfRotateIsClockwise(Vector me, Pos dest) {
		double baseAngle = processAngleOfVector(dest, me.mid);
		if (baseAngle < 180) {
			if (me.angle - baseAngle > 0 & me.angle - baseAngle < 180)
				return -1;
			else
				return 1;
		} else {
			if (baseAngle - me.angle > 0 & baseAngle - me.angle < 180)
				return 1;
			else
				return -1;
		}

	}

	public static Pos processRotateCenterForMyVect(Vector ship, int ClockWise) {
		double m = -1 / Math.tan(ship.angle);
		double q = ClockWise * ROTATE_RADIUS / Math.sqrt(1 + m * m);
		// double q1=ClockWise*ROTATE_RADIUS/Math.sqrt(1+m*m)*((ship.angle<180)?
		// 1 : -1);
		if (ship.angle < 180) {

			return new Pos(ship.mid.x + ((int) q), ship.mid.y + ((int) (m * q)));
		} else
			return new Pos(ship.mid.x + ((int) -q), ship.mid.y
					+ ((int) -(m * q)));
	}

	public static Pos processIntersectionPoint(Circle C, Pos pos) {
		double m = (C.center.y - pos.y) / (C.center.x - pos.x);
		double q = C.radius / Math.sqrt(1 + m * m);
		if (pos.x < C.center.x)
			q = -q;
		return new Pos(C.center.x + ((int) q), C.center.y + ((int) (q * m)));
	}

	public static double processAngleToTurn(double courentAngle,
			double lastAngle, int Clockwise) {
		if (Clockwise == 1)
			return (courentAngle > lastAngle) ? (courentAngle - lastAngle)
					: (360 - lastAngle + courentAngle);
		else
			return (courentAngle < lastAngle) ? (lastAngle - courentAngle)
					: (360 + lastAngle - courentAngle);

	}

	public static boolean IsPointBetweenTwoPoints(Pos p, Pos p1, Pos p2) {
		// double ang1 = processAngleOfVector(p1, p);
		double ang = processAngleOfVector(p1, p2);
		double firstAngle = processAngleBetweenLine(
				processAngleOfVector(p1, p), ang);
		double secondAngle = processAngleBetweenLine(
				processAngleOfVector(p2, p), getOpositeSideAngle(ang));
		if (firstAngle < 90 && secondAngle < 90)
			return true;
		else
			return false;
	}

	public static boolean IsPointBetweenTwoPoints(Pos p, Pos p1, Pos p2,
			double baseAngle) {
		double firstAngle = processAngleBetweenLine(
				processAngleOfVector(p1, p), baseAngle);
		double secondAngle = processAngleBetweenLine(
				processAngleOfVector(p2, p), getOpositeSideAngle(baseAngle));
		if (firstAngle < 90 && secondAngle < 90)
			return true;
		else
			return false;
	}

	public static double getOpositeSideAngle(double angle) {
		return (angle < 180) ? (angle + 180) : (angle - 180);
	}

	public static double processAngleBetweenLine(double ang1, double ang2) {
		double angle = Math.abs(ang1 - ang2);
		return (angle < 180) ? angle : (360.0 - angle);
	}

	public static int getFurthestPos(ArrayList<Pos> poses, Pos start, Pos end,
			Pos AnswerPos) {
		Line line = new Line(start, end);
		double baseAngle = processAngleOfVector(start, end);
		Pos furthest = null;
		double distance = 0;
		int findPos = -1;
		for (Pos pos : poses) {
			if (processDistanceFromLine(line, pos) < 5
					&& IsPointBetweenTwoPoints(pos, start, end, baseAngle)) {
				double tempDistance = processDistanceOfPoses(pos, start);
				if (tempDistance > distance) {
					findPos = poses.indexOf(pos);
					distance = tempDistance;
					furthest = pos;
				}
			}
		}
		if (furthest != null)
			AnswerPos = furthest;
		return findPos;
	}

	public static double processDistanceFromLine(Line l, Pos p) {
		return Math.abs(l.a * p.x + l.b * p.y + l.c)
				/ Math.sqrt(l.a * l.a + l.b * l.b);
	}

	public static double processDistanceFromLine(double a, double b, double c,
			double square, Pos p) {
		return Math.abs(a * p.x + b * p.y + c) / square;
	}

	public static Pos processPosOnCircle(Line line, Pos center) {
		double m = line.a / line.b;
		double q = ICELAND_RADIUS / Math.sqrt(1 + m * m);
		if (isInrightSideOfLine(line, center))
			return new Pos((int) (center.x - q), (int) (center.y + (-m * q)));
		else
			return new Pos((int) (center.x + q), (int) (center.y + (m * q)));
	}

	public static boolean isAboveLine(Line line, Pos pos) {
		if (pos.y < ((-line.a * pos.x) - line.c) / line.b)
			return false;
		else
			return true;
	}

	public static boolean isAboveLine(Pos p1, Pos p2, Pos pos) {
		if (pos.y < (p1.y - p2.y) * (pos.x - p1.x) / (p1.x - p2.x) + p1.y)
			return false;
		else
			return true;
	}

	public static boolean isInrightSideOfLine(Pos p1, Pos p2, Pos pos) {
		if (pos.x > (pos.y - p1.y) * (p1.x - p2.x) / (p1.y - p2.y) + p1.x)
			return true;
		else
			return false;

	}

	public static boolean isInrightSideOfLine(Line line, Pos pos) {
		if (pos.x > (-line.b * pos.y - line.c) / line.a)
			return true;
		else
			return false;

	}
	//
	// ---------------------------------------------------------------------------------
	/*
	 * public static double ProcessAngleToTurn(Circle c1, Circle c2, Vector vec)
	 * { double shib = 0; double ang1 =
	 * processHalfAngleofView(processCirclesViewPoint(c1, c2, shib), c1); double
	 * ang2 = vec.angle - processAngleFromShib(shib); return 180.0 - (ang1 +
	 * ang2); }
	 * 
	 * public static double processAngleOfLines(double shib1, double shib2) {
	 * return (shib1 - shib2) / (1 + shib1 * shib2); }
	 * 
	 * public static double processAngleFromShib(double shib) { return
	 * Math.atan(shib); }
	 * 
	 * public static Pos processCirclesViewPoint(Circle c1, Circle c2, double
	 * shib) { double q = c1.radius * processDistanceOfPoses(c1.center,
	 * c2.center) / (c2.radius - c1.radius); double m = processShib(c1.center,
	 * c2.center); shib = m;
	 * 
	 * return new Pos((int) (q / Math.sqrt(1 + m * m)), (int) (m * q / Math
	 * .sqrt(1 + m * m))); }
	 * 
	 * public static Pos processClockwiseRotateCenter(Vector me, Pos answer) {
	 * double m = -1 / Math.tan(me.angle); double q = ROTATE_RADIUS /
	 * Math.sqrt(1 + m * m); if (answer != null) { answer = new Pos((int) (-q +
	 * me.mid.x), (int) (me.mid.y - m * q)); } return new Pos((int) (me.mid.x +
	 * q), (int) (me.mid.y + m * q)); }
	 * 
	 * public static Pos processUnClockwiseRotateCenter(Vector me, Pos answer) {
	 * double m = -1 / Math.tan(me.angle); double q = ROTATE_RADIUS /
	 * Math.sqrt(1 + m * m); if (answer != null) { } return new Pos(1, 0); }
	 * 
	 * public static double processShib(Pos pos1, Pos pos2) {
	 * 
	 * return ((pos1.y - pos2.y) / (pos1.x - pos2.x)); }
	 */

}

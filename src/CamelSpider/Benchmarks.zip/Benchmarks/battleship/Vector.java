public class Vector {
	Pos mid;
	double angle;
}